<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
$diag = ['time' => time(), 'php' => phpversion()];

// 1. 检查 config.php
$config_ok = false;
$config_path = __DIR__ . '/data/config.php';
if (file_exists($config_path)) {
    $diag['config_path'] = $config_path;
    $diag['config_exists'] = true;
    // 尝试加载
    define('IN_AUTH', true);
    require_once $config_path;
    $diag['salt_defined'] = defined('GLOBAL_SALT');
    $diag['module_version'] = defined('MODULE_VERSION') ? MODULE_VERSION : 'undefined';
    $diag['data_dir'] = defined('DATA_DIR') ? DATA_DIR : 'undefined';
    $diag['data_dir_writable'] = is_writable(DATA_DIR);
    $config_ok = true;
} else {
    $diag['config_path'] = $config_path;
    $diag['config_exists'] = false;
}

// 2. 检查 openssl
$diag['openssl'] = extension_loaded('openssl');

// 3. 检查数据文件
$diag['data_files'] = [];
if (defined('DATA_DIR')) {
    foreach (['auth_codes.dat', 'devices.dat', 'blacklist.dat'] as $f) {
        $p = DATA_DIR . '/' . $f;
        $diag['data_files'][$f] = file_exists($p) ? (filesize($p) . ' bytes') : 'not exist';
    }
}

// 4. 测试 AES 加解密
if ($config_ok && $diag['openssl']) {
    $test = aes_enc('test');
    $dec = aes_dec($test);
    $diag['aes_test'] = ($dec === 'test') ? 'ok' : 'fail';
}

// 5. 测试设备码计算
if ($config_ok) {
    $dc = compute_device_code('123456789012345', 'TEST123');
    $diag['device_code_test'] = $dc ? $dc : 'fail';
}

// 6. 检查所有 PHP 端点
$diag['endpoints'] = [];
foreach (['activate.php', 'get_code.php', 'heartbeat.php', 'report_sell.php'] as $f) {
    $diag['endpoints'][$f] = file_exists(__DIR__ . '/' . $f) ? 'ok' : 'missing';
}

$diag['overall'] = ($config_ok && $diag['openssl'] && $diag['data_dir_writable']) ? 'ok' : 'fail';

echo json_encode($diag, JSON_PRETTY_PRINT);
