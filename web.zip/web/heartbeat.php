<?php
define('IN_AUTH', true);
require_once __DIR__ . '/data/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { header('Access-Control-Allow-Origin: *'); header('Access-Control-Allow-Methods: POST, OPTIONS'); header('Access-Control-Allow-Headers: Content-Type'); exit; } if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(1, 'err');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) json_out(1, 'err');
if (!check_sign($input)) json_out(1, 'err');
$dc = strtoupper(preg_replace('/[^A-Z0-9]/', '', $input['device_code'] ?? ''));
if (strlen($dc) !== 16) json_out(1, 'err');
if (is_blacklisted($dc)) json_out(1, 'err');
$imei = substr(preg_replace('/[^0-9]/', '', $input['imei'] ?? ''), 0, 19);
$serialno = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $input['serialno'] ?? ''), 0, 64);
$expect_dc = compute_device_code($imei, $serialno);
if ($expect_dc !== $dc) { add_blacklist($dc, 'device_code_mismatch', $serialno); json_out(1, 'err'); }
$tk = $input['token'] ?? '';
$dec = aes_dec($tk);
if ($dec === null) json_out(1, 'err');
$info = json_decode($dec, true);
if (!$info || ($info['dc'] ?? '') !== $dc || ($info['ver'] ?? '') !== MODULE_VERSION) json_out(1, 'err');
if (($info['exp'] ?? 0) < time()) json_out(1, 'err');
$now = time();
$new_exp = $now + 86400 * 30;
$serialno = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $input['serialno'] ?? ''), 0, 64);
$devices = load_data('devices.dat');
$devices[$dc]['last_heartbeat'] = $now;
if ($imei) $devices[$dc]['imei'] = $imei;
if ($serialno) $devices[$dc]['serialno'] = $serialno;
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', $devices[$dc]['ip_history'] ?? [])) {
    $devices[$dc]['ip_history'][] = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
save_data('devices.dat', $devices);
$token = aes_enc(json_encode(['dc' => $dc, 'ac' => $info['ac'], 'ver' => MODULE_VERSION, 'exp' => $new_exp]));
json_out(0, 'ok', ['expire_time' => $new_exp, 'token' => $token]);
