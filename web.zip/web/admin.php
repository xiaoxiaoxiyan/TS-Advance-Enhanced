<?php
require_once __DIR__ . '/data/config.php';

$admin_hash = defined('ADMIN_HASH') ? ADMIN_HASH : '$2y$10$defaultplaceholderhashfortest';
$cookie_hash = hash('sha256', $admin_hash);
$login = false;
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pwd'])) {
    if (password_verify($_POST['pwd'], $admin_hash)) {
        setcookie('tsa_admin', $cookie_hash, time() + 3600, '/');
        $login = true;
    } else {
        $err = '密码错误';
    }
} elseif (isset($_COOKIE['tsa_admin']) && $_COOKIE['tsa_admin'] === $cookie_hash) {
    $login = true;
}

$msg = '';
if ($login && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'unban' && !empty($_POST['code'])) {
        $code = strtoupper(preg_replace('/[^A-Z0-9]/', '', $_POST['code']));
        if (remove_blacklist($code)) {
            $msg = '已解禁：' . htmlspecialchars($code);
        } else {
            $msg = '未找到该设备码：' . htmlspecialchars($code);
        }
    }
    if (isset($_POST['action']) && $_POST['action'] === 'ban' && !empty($_POST['code'])) {
        $code = strtoupper(preg_replace('/[^A-Z0-9]/', '', $_POST['code']));
        add_blacklist($code, 'manual');
        $msg = '已封禁：' . htmlspecialchars($code);
    }
}

$blacklist = load_data('blacklist.dat');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>TS Advance 管理后台</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:"PingFang SC","Noto Sans SC",system-ui,sans-serif;background:#f7f7f8;color:#111;padding:20px;min-height:100vh}
.box{max-width:640px;margin:0 auto;background:#fff;border:1px solid #e5e5e5;border-radius:16px;padding:28px}
h1{font-size:22px;font-weight:600;margin-bottom:6px}
.desc{font-size:13px;color:#666;margin-bottom:24px}
input[type="password"],input[type="text"]{width:100%;padding:12px 14px;border:1px solid #d4d4d4;border-radius:8px;font-size:15px;margin-bottom:12px}
input:focus{outline:none;border-color:#111}
button{padding:10px 18px;border:none;border-radius:8px;background:#111;color:#fff;font-size:14px;font-weight:600;cursor:pointer}
button.secondary{background:#fff;color:#111;border:1px solid #d4d4d4}
.err{color:#cf1322;font-size:13px;margin-bottom:12px}
.msg{color:#389e0d;font-size:13px;margin-bottom:12px}
.row{display:flex;gap:10px;margin-bottom:20px}
.row input{flex:1;margin-bottom:0}
table{width:100%;border-collapse:collapse;font-size:13px;margin-top:16px}
th,td{text-align:left;padding:10px 8px;border-bottom:1px solid #eee}
th{color:#666;font-weight:600;font-size:12px}
.unban{color:#cf1322;cursor:pointer}
.empty{color:#999;text-align:center;padding:40px 0;font-size:13px}
</style>
</head>
<body>
<div class="box">
<h1>TS Advance 管理后台</h1>
<p class="desc">设备码黑名单管理</p>
<?php if (!$login): ?>
<?php if ($err): ?><div class="err"><?php echo $err; ?></div><?php endif; ?>
<form method="POST">
<input type="password" name="pwd" placeholder="管理员密码" autofocus>
<button type="submit">登录</button>
</form>
<?php else: ?>
<?php if ($msg): ?><div class="msg"><?php echo $msg; ?></div><?php endif; ?>
<form method="POST">
<input type="hidden" name="action" id="action" value="">
<div class="row">
<input type="text" name="code" placeholder="输入16位设备码" maxlength="16" pattern="[A-Za-z0-9]{16}">
<button type="submit" onclick="document.getElementById('action').value='ban'">封禁</button>
<button type="submit" class="secondary" onclick="document.getElementById('action').value='unban'">解禁</button>
</div>
</form>
<h2 style="font-size:15px;font-weight:600;margin:24px 0 8px">当前黑名单（<?php echo count($blacklist); ?>）</h2>
<?php if (empty($blacklist)): ?>
<div class="empty">黑名单为空</div>
<?php else: ?>
<table>
<tr><th>设备码</th><th>原因</th><th>时间</th><th>IMEI</th><th>序列号</th></tr>
<?php foreach ($blacklist as $code => $info): ?>
<tr>
<td><?php echo htmlspecialchars($code); ?></td>
<td><?php echo htmlspecialchars($info['reason'] ?? ''); ?></td>
<td><?php echo date('Y-m-d H:i', $info['add_time'] ?? 0); ?></td>
<td><?php echo htmlspecialchars($info['imei'] ?? ''); ?></td>
<td><?php echo htmlspecialchars($info['serialno'] ?? ''); ?></td>
</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>
<?php endif; ?>
</div>
</body>
</html>
