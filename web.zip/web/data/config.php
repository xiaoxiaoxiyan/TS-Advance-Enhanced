<?php
if (!defined('IN_AUTH')) exit;
define('ENCRYPT_KEY', 'K9mP2vL5nQ8rT3bX7yZ1wE4aS6dF0gHj');
define('ENCRYPT_IV', 'LmN7pQr9sTu2vWx5');
define('GLOBAL_SALT', 'Tq8#kL3mNpQw4$Rs7*Yz9@Xa2&Vb5Cj');
define('MODULE_VERSION', 'v1.4');
define('ADMIN_HASH', '$2b$12$SCTYfibXT2VsThdq4U3wB.EMjnzsRGaNdt19ZravvYpnFdoRLtWaK');
define('IP_LIMIT_COUNT', 3);
define('OFFLINE_GRACE_HOURS', 72);
define('DATA_DIR', dirname(__FILE__));
define('API_BASE', 'http://yanzhen.bt1.886966.xyz/web/');
function aes_enc($data) {
    return base64_encode(openssl_encrypt($data, 'AES-128-CBC', ENCRYPT_KEY, OPENSSL_RAW_DATA, ENCRYPT_IV));
}
function aes_dec($data) {
    $r = openssl_decrypt(base64_decode($data), 'AES-128-CBC', ENCRYPT_KEY, OPENSSL_RAW_DATA, ENCRYPT_IV);
    return $r === false ? null : $r;
}
function load_data($file) {
    $path = DATA_DIR . '/' . $file;
    if (!file_exists($path)) return [];
    $raw = file_get_contents($path);
    if (empty($raw)) return [];
    $dec = aes_dec($raw);
    if ($dec === null) {
        rename($path, $path . '.bak.' . time());
        return [];
    }
    $arr = json_decode($dec, true);
    return is_array($arr) ? $arr : [];
}
function save_data($file, $data) {
    $path = DATA_DIR . '/' . $file;
    $fp = fopen($path, 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    fwrite($fp, aes_enc(json_encode($data)));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}
function check_sign($params) {
    if (empty($params['device_code']) || empty($params['timestamp']) || empty($params['sign'])) return false;
    $ts = intval($params['timestamp']);
    if (abs(time() - $ts) > 300) return false;
    $expect = md5($params['device_code'] . $params['timestamp'] . GLOBAL_SALT);
    return hash_equals($expect, $params['sign']);
}
function check_sign_sell($params) {
    if (empty($params['timestamp']) || empty($params['sign'])) return false;
    $ts = intval($params['timestamp']);
    if (abs(time() - $ts) > 300) return false;
    $expect = md5($params['timestamp'] . GLOBAL_SALT);
    return hash_equals($expect, $params['sign']);
}
function compute_device_code($imei, $serialno) {
    $id = '';
    if (!empty($imei) && strlen($imei) >= 8) $id = $imei;
    elseif (!empty($serialno) && strlen($serialno) >= 2) $id = $serialno;
    else return '';
    $hash = hash('sha256', $id . GLOBAL_SALT, true);
    $alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $out = '';
    for ($i = 0; $i < 16; $i++) $out .= $alphabet[ord($hash[$i]) % 36];
    return $out;
}
function is_blacklisted($code) {
    $bl = load_data('blacklist.dat');
    return isset($bl[$code]);
}
function add_blacklist($code, $reason = '', $serialno = '', $imei = '') {
    $bl = load_data('blacklist.dat');
    $bl[$code] = ['add_time' => time(), 'reason' => $reason, 'report_source' => 'auto', 'imei' => substr(preg_replace('/[^0-9]/', '', $imei), 0, 19), 'serialno' => substr(preg_replace('/[^A-Za-z0-9_-]/', '', $serialno), 0, 64)];
    save_data('blacklist.dat', $bl);
}
function remove_blacklist($code) {
    $bl = load_data('blacklist.dat');
    if (isset($bl[$code])) {
        unset($bl[$code]);
        save_data('blacklist.dat', $bl);
        return true;
    }
    return false;
}
function ip_limit($key, $max, $hours = 24) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $data = load_data('ip_limit.dat');
    $now = time();
    if (!isset($data[$ip])) $data[$ip] = [];
    if (!isset($data[$ip][$key])) $data[$ip][$key] = ['count' => 0, 'last_time' => 0];
    if ($now - $data[$ip][$key]['last_time'] > $hours * 3600) {
        $data[$ip][$key] = ['count' => 0, 'last_time' => $now];
    }
    $data[$ip][$key]['count']++;
    $data[$ip][$key]['last_time'] = $now;
    save_data('ip_limit.dat', $data);
    return $data[$ip][$key]['count'] <= $max;
}
function ip_limit_check($key, $max, $hours = 24) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $data = load_data('ip_limit.dat');
    if (!isset($data[$ip][$key])) return true;
    $now = time();
    if ($now - $data[$ip][$key]['last_time'] > $hours * 3600) return true;
    return $data[$ip][$key]['count'] < $max;
}
function json_out($code, $msg, $data = null) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    $out = ['code' => $code, 'msg' => $msg];
    if ($data !== null) $out['data'] = $data;
    echo json_encode($out);
    exit;
}
function gen_code() {
    return strtoupper(substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZ23456789'), 0, 16));
}
function xss_clean($str) {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}
