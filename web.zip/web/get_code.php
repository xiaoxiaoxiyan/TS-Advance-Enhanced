<?php
define('IN_AUTH', true);
require_once __DIR__ . '/data/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { header('Access-Control-Allow-Origin: *'); header('Access-Control-Allow-Methods: POST, OPTIONS'); header('Access-Control-Allow-Headers: Content-Type'); exit; } if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(1, 'err');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) json_out(1, 'err');
if (!check_sign($input)) json_out(1, 'err');
$dc = strtoupper(preg_replace('/[^A-Z0-9]/', '', $input['device_code'] ?? ''));
if (strlen($dc) !== 16) json_out(1, 'err');
if (is_blacklisted($dc)) json_out(1, 'err');
if (!ip_limit_check('get_code', IP_LIMIT_COUNT)) json_out(1, 'freq');
$codes = load_data('auth_codes.dat');
$devices = load_data('devices.dat');
if (isset($codes[$dc]) && $codes[$dc]['version'] === MODULE_VERSION && $codes[$dc]['status'] === 'active') {
    json_out(0, 'ok', ['auth_code' => $codes[$dc]['auth_code'], 'expire_time' => $codes[$dc]['expire_time']]);
}
if (isset($codes[$dc]) && $codes[$dc]['status'] !== 'active') {
    json_out(1, 'err');
}
$ac = gen_code();
while (isset($codes[$ac]) || array_search($ac, array_column($codes, 'auth_code')) !== false) $ac = gen_code();
$now = time();
$codes[$dc] = ['auth_code' => $ac, 'device_code' => $dc, 'create_time' => $now, 'expire_time' => $now + 86400 * 30, 'version' => MODULE_VERSION, 'status' => 'active'];
$devices[$dc] = ['auth_code' => $ac, 'activate_time' => 0, 'last_heartbeat' => 0, 'ip_history' => [$_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'], 'version' => MODULE_VERSION];
save_data('auth_codes.dat', $codes);
save_data('devices.dat', $devices);
ip_limit('get_code', IP_LIMIT_COUNT);
json_out(0, 'ok', ['auth_code' => $ac, 'expire_time' => $codes[$dc]['expire_time']]);
