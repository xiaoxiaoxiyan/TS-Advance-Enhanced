<?php
session_start();
define('IN_AUTH', true);
require_once dirname(__DIR__) . '/data/config.php';
$action = $_GET['a'] ?? 'login';
$page = max(1, intval($_GET['page'] ?? 1));
$per = 20;
$offset = ($page - 1) * $per;
function login_check() {
    if (empty($_SESSION['admin']) || $_SESSION['admin'] < time() - 1800) {
        header('Location: ?a=login');
        exit;
    }
    $_SESSION['admin'] = time();
}
function login_fail() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $f = DATA_DIR . '/login_fail_' . md5($ip) . '.dat';
    $n = 0;
    if (file_exists($f)) $n = intval(file_get_contents($f));
    $n++;
    file_put_contents($f, $n);
    if ($n >= 5) {
        touch($f, time() + 3600);
        return 'locked';
    }
    return 'fail';
}
function login_locked() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $f = DATA_DIR . '/login_fail_' . md5($ip) . '.dat';
    if (!file_exists($f)) return false;
    $t = filemtime($f);
    if ($t > time()) return true;
    unlink($f);
    return false;
}
function login_ok() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $f = DATA_DIR . '/login_fail_' . md5($ip) . '.dat';
    if (file_exists($f)) unlink($f);
}
if ($action === 'login') {
    if (!empty($_POST['pwd'])) {
        if (login_locked()) { $err = 'locked'; }
        elseif (password_verify($_POST['pwd'], ADMIN_HASH)) {
            $_SESSION['admin'] = time();
            login_ok();
            header('Location: ?a=dash');
            exit;
        } else {
            $r = login_fail();
            $err = $r === 'locked' ? 'locked' : 'fail';
        }
    }
    ?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TS Advance 后台管理</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:"PingFang SC","Noto Sans SC",system-ui,sans-serif;background:#fff;color:#111;display:flex;justify-content:center;align-items:center;height:100vh;padding:20px}.box{border:1px solid #e5e5e5;border-radius:16px;padding:40px;width:100%;max-width:360px}h2{font-size:20px;margin-bottom:8px;font-weight:600}.sub{font-size:13px;color:#888;margin-bottom:20px}input{width:100%;padding:12px 14px;margin-bottom:12px;border:1px solid #d4d4d4;border-radius:8px;font-size:15px;background:#fff;color:#111}input:focus{outline:none;border-color:#111}button{width:100%;padding:12px;border:none;border-radius:8px;background:#111;color:#fff;font-size:15px;font-weight:600;cursor:pointer}.err{margin-top:12px;padding:10px;background:#fff5f5;border:1px solid #ffccc7;border-radius:8px;color:#cf1322;font-size:13px}</style></head><body><div class="box"><h2>后台登录</h2><p class="sub">TS Advance 管理系统</p><?php if(!empty($err))echo '<div class="err">'.($err==='locked'?'IP 已被锁定 1 小时':'密码错误').'</div>';?><form method="post"><input type="password" name="pwd" placeholder="请输入管理员密码" required><button type="submit">登录</button></form></div></body></html><?php
    exit;
}
login_check();
$codes = load_data('auth_codes.dat');
$bl = load_data('blacklist.dat');
$devices = load_data('devices.dat');
$reports = load_data('reports.dat');
$total_auth = count(array_filter($codes, function($v){return ($v['status']??'')==='active';}));
$total_bl = count($bl);
$total_rp = count(array_filter($reports, function($v){return ($v['status']??'')==='pending';}));
$today = array_filter($devices, function($v){return ($v['activate_time']??0) > strtotime('today');});
?><!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TS Advance 后台管理</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:"PingFang SC","Noto Sans SC",system-ui,sans-serif;background:#f7f7f7;color:#111;font-size:14px}.nav{background:#fff;border-bottom:1px solid #e5e5e5;padding:0 20px;display:flex;gap:8px;align-items:center}.nav a{color:#555;text-decoration:none;padding:14px 12px;font-size:14px}.nav a:hover{color:#111}.nav a.active{color:#111;border-bottom:2px solid #111}.nav .logout{margin-left:auto;color:#999}.container{max-width:1200px;margin:0 auto;padding:24px 20px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:24px}.card{background:#fff;border:1px solid #e5e5e5;border-radius:12px;padding:20px}.card h3{font-size:12px;color:#888;margin-bottom:8px;font-weight:400}.card .num{font-size:28px;font-weight:600;color:#111}table{width:100%;border-collapse:collapse;margin-top:12px;font-size:13px;background:#fff;border:1px solid #e5e5e5;border-radius:12px;overflow:hidden}th,td{padding:12px;text-align:left;border-bottom:1px solid #f0f0f0}th{color:#888;font-weight:600;background:#fafafa}tr:hover{background:#fafafa}.btn{padding:6px 14px;border:none;border-radius:6px;cursor:pointer;font-size:13px;text-decoration:none;display:inline-block}.btn-red{background:#fff;color:#cf1322;border:1px solid #ffccc7}.btn-green{background:#111;color:#fff}.btn-blue{background:#fff;color:#111;border:1px solid #d4d4d4}.search{display:flex;gap:8px;margin-bottom:16px}.search input{flex:1;padding:10px 12px;background:#fff;border:1px solid #e5e5e5;border-radius:8px;font-size:14px}.pagination{display:flex;gap:8px;margin-top:16px;justify-content:center}.pagination a{padding:6px 12px;background:#fff;border:1px solid #e5e5e5;border-radius:6px;color:#555;text-decoration:none}.pagination a.active{background:#111;color:#fff;border-color:#111}.form-group{margin-bottom:16px}.form-group label{display:block;margin-bottom:6px;color:#555;font-size:13px}.form-group input,.form-group select{width:100%;padding:10px 12px;background:#fff;border:1px solid #e5e5e5;border-radius:8px;font-size:14px}.alert{padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:13px}.alert-ok{background:#f6ffed;border:1px solid #b7eb8f;color:#389e0d}.alert-err{background:#fff5f5;border:1px solid #ffccc7;color:#cf1322}.mt12{margin-top:12px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px}.actions a{margin-bottom:0}.small{font-size:12px;color:#888}.wrap{word-break:break-all;max-width:220px}</style></head><body>
<div class="nav">
<a href="?a=dash" class="<?php echo $action==='dash'?'active':'';?>">仪表盘</a>
<a href="?a=auth" class="<?php echo $action==='auth'?'active':'';?>">授权码</a>
<a href="?a=bl" class="<?php echo $action==='bl'?'active':'';?>">黑名单</a>
<a href="?a=rp" class="<?php echo $action==='rp'?'active':'';?>">举报</a>
<a href="?a=cfg" class="<?php echo $action==='cfg'?'active':'';?>">设置</a>
<a href="?a=logout" class="logout">退出</a>
</div>
<div class="container">
<?php
if ($action === 'dash') {
    ?><div class="cards"><div class="card"><h3>有效授权码</h3><div class="num"><?php echo $total_auth;?></div></div><div class="card"><h3>黑名单数量</h3><div class="num"><?php echo $total_bl;?></div></div><div class="card"><h3>待处理举报</h3><div class="num"><?php echo $total_rp;?></div></div><div class="card"><h3>今日激活</h3><div class="num"><?php echo count($today);?></div></div></div><div class="actions"><a href="?a=auth&gen=1" class="btn btn-green">生成授权码</a><a href="?a=export_auth" class="btn btn-blue">导出授权码 CSV</a><a href="?a=export_bl" class="btn btn-blue">导出黑名单 CSV</a><a href="?a=export_rp" class="btn btn-blue">导出举报 CSV</a></div><?php
}
elseif ($action === 'auth') {
    if (!empty($_POST['bind_dc'])) {
        $bdc = strtoupper(preg_replace('/[^A-Z0-9]/', '', $_POST['bind_dc']));
        if (strlen($bdc) === 16) {
            $nc = gen_code();
            $codes[$bdc] = ['auth_code' => $nc, 'device_code' => $bdc, 'create_time' => time(), 'expire_time' => time() + 86400 * 30, 'version' => MODULE_VERSION, 'status' => 'active'];
            save_data('auth_codes.dat', $codes);
            echo '<div class="alert alert-ok">已为设备码 '.$bdc.' 生成授权码：'.$nc.'</div>';
        } else {
            echo '<div class="alert alert-err">设备码必须是16位字母数字</div>';
        }
    }
    if (!empty($_GET['gen'])) {
        $nc = gen_code();
        $codes[$nc] = ['auth_code' => $nc, 'device_code' => '', 'create_time' => time(), 'expire_time' => time() + 86400 * 30, 'version' => MODULE_VERSION, 'status' => 'active'];
        save_data('auth_codes.dat', $codes);
        echo '<div class="alert alert-ok">已生成未分配授权码：'.$nc.'</div>';
    }
    if (!empty($_GET['ban'])) {
        $bdc = strtoupper(preg_replace('/[^A-Z0-9]/', '', $_GET['ban']));
        if (strlen($bdc) === 16) {
            add_blacklist($bdc, 'manual');
            echo '<div class="alert alert-ok">已封禁：'.$bdc.'</div>';
        }
    }
    $q = strtoupper(trim($_GET['q'] ?? ''));
    $list = [];
    foreach ($codes as $k => $v) {
        if ($v['status'] !== 'active') continue;
        if ($q && strpos($v['device_code'], $q) === false && strpos($v['auth_code'], $q) === false) continue;
        $list[] = $v;
    }
    $total = count($list);
    $list = array_slice($list, $offset, $per);
    ?><div class="actions" style="align-items:flex-start"><form method="post" style="display:flex;gap:8px;flex:1;flex-wrap:wrap"><input type="hidden" name="a" value="auth"><input type="text" name="bind_dc" placeholder="输入16位设备码" maxlength="16" style="flex:1;min-width:160px" required><button class="btn btn-green">为指定设备生成授权码</button></form><a href="?a=auth&gen=1" class="btn btn-blue">批量生成空白授权码</a></div><div class="search"><form method="get" style="display:flex;gap:8px;width:100%"><input type="hidden" name="a" value="auth"><input type="text" name="q" value="<?php echo htmlspecialchars($q);?>" placeholder="搜索设备码或授权码"><button class="btn btn-green">搜索</button></form></div><table><tr><th>设备码</th><th>授权码</th><th>IMEI</th><th>序列号</th><th>版本</th><th>创建时间</th><th>到期时间</th><th>操作</th></tr><?php foreach($list as $v){?><tr><td class="wrap"><?php echo $v['device_code']?:'(未分配)';?></td><td class="wrap"><?php echo $v['auth_code'];?></td><td><?php echo $v['device_code'] && ($devices[$v['device_code']]['imei'] ?? '') ? $devices[$v['device_code']]['imei'] : '-';?></td><td><?php echo $v['device_code'] && ($devices[$v['device_code']]['serialno'] ?? '') ? $devices[$v['device_code']]['serialno'] : '-';?></td><td><?php echo $v['version'];?></td><td><?php echo date('Y-m-d H:i',$v['create_time']);?></td><td><?php echo date('Y-m-d H:i',$v['expire_time']);?></td><td><?php if($v['device_code']){?><a href="?a=auth&ban=<?php echo $v['device_code'];?>" class="btn btn-red" onclick="return confirm('确认封禁该设备？')">封禁</a><?php }else{?>-<?php }?></td></tr><?php }?></table><div class="pagination"><?php for($i=1;$i<=ceil($total/$per);$i++){?><a href="?a=auth&page=<?php echo $i;?>&q=<?php echo urlencode($q);?>" class="<?php echo $i===$page?'active':'';?>"><?php echo $i;?></a><?php }?></div><?php
}
elseif ($action === 'bl') {
    $q = strtoupper(trim($_GET['q'] ?? ''));
    $list = [];
    foreach ($bl as $k => $v) {
        if ($q && strpos($k, $q) === false) continue;
        $list[] = array_merge(['code' => $k], $v);
    }
    $total = count($list);
    $list = array_slice($list, $offset, $per);
    ?><div class="search"><form method="get" style="display:flex;gap:8px;width:100%"><input type="hidden" name="a" value="bl"><input type="text" name="q" value="<?php echo htmlspecialchars($q);?>" placeholder="搜索设备码"><button class="btn btn-green">搜索</button></form></div><table><tr><th>设备码</th><th>原因</th><th>IMEI</th><th>序列号</th><th>封禁时间</th></tr><?php foreach($list as $v){?><tr><td class="wrap"><?php echo $v['code'];?></td><td><?php echo $v['reason'];?></td><td><?php echo $v['imei'] ?? '-';?></td><td><?php echo $v['serialno'] ?? '-';?></td><td><?php echo date('Y-m-d H:i',$v['add_time']);?></td></tr><?php }?></table><div class="pagination"><?php for($i=1;$i<=ceil($total/$per);$i++){?><a href="?a=bl&page=<?php echo $i;?>&q=<?php echo urlencode($q);?>" class="<?php echo $i===$page?'active':'';?>"><?php echo $i;?></a><?php }?></div><?php
}
elseif ($action === 'rp') {
    if (!empty($_GET['done'])) {
        $id = intval($_GET['done']);
        if (isset($reports[$id])) {
            $reports[$id]['status'] = 'done';
            save_data('reports.dat', $reports);
        }
    }
    $list = [];
    foreach ($reports as $k => $v) {
        $list[] = array_merge(['id' => $k], $v);
    }
    $total = count($list);
    $list = array_slice($list, $offset, $per);
    ?><table><tr><th>ID</th><th>内容</th><th>联系方式</th><th>证据</th><th>IP</th><th>时间</th><th>状态</th><th>操作</th></tr><?php foreach($list as $v){?><tr><td><?php echo $v['id'];?></td><td class="wrap"><?php echo nl2br(htmlspecialchars($v['content']));?></td><td><?php echo htmlspecialchars($v['contact']);?></td><td class="wrap"><?php echo htmlspecialchars($v['evidence']);?></td><td><?php echo $v['submit_ip'];?></td><td><?php echo date('Y-m-d H:i',$v['submit_time']);?></td><td><?php echo $v['status']==='pending'?'待处理':'已处理';?></td><td><?php if($v['status']==='pending'){?><a href="?a=rp&done=<?php echo $v['id'];?>" class="btn btn-green">标记已处理</a><?php }?></td></tr><?php }?></table><div class="pagination"><?php for($i=1;$i<=ceil($total/$per);$i++){?><a href="?a=rp&page=<?php echo $i;?>" class="<?php echo $i===$page?'active':'';?>"><?php echo $i;?></a><?php }?></div><?php
}
elseif ($action === 'cfg') {
    if (!empty($_POST['save'])) {
        $new_ver = trim($_POST['version'] ?? MODULE_VERSION);
        $new_ip = intval($_POST['ip_limit'] ?? 3);
        $new_off = intval($_POST['offline'] ?? 72);
        $new_pwd = trim($_POST['pwd'] ?? '');
        $cfg = file_get_contents(DATA_DIR . '/config.php');
        $cfg = preg_replace("/define\\('MODULE_VERSION', '.*?'\\);/", "define('MODULE_VERSION', '" . addslashes($new_ver) . "');", $cfg);
        $cfg = preg_replace("/define\\('IP_LIMIT_COUNT', \\d+\\);/", "define('IP_LIMIT_COUNT', $new_ip);", $cfg);
        $cfg = preg_replace("/define\\('OFFLINE_GRACE_HOURS', \\d+\\);/", "define('OFFLINE_GRACE_HOURS', $new_off);", $cfg);
        if ($new_pwd) {
            $hash = password_hash($new_pwd, PASSWORD_BCRYPT);
            $cfg = preg_replace("/define\\('ADMIN_HASH', '.*?'\\);/", "define('ADMIN_HASH', '" . addslashes($hash) . "');", $cfg);
        }
        file_put_contents(DATA_DIR . '/config.php', $cfg);
        echo '<div class="alert alert-ok">设置已保存</div>';
    }
    if (!empty($_POST['backup'])) {
        $zip = new ZipArchive();
        $bf = DATA_DIR . '/backup_' . date('Ymd_His') . '.zip';
        $zip->open($bf, ZipArchive::CREATE);
        foreach (glob(DATA_DIR . '/*.dat') as $f) $zip->addFile($f, basename($f));
        $zip->close();
        echo '<div class="alert alert-ok">已备份：'.basename($bf).'</div>';
    }
    ?><form method="post"><div class="form-group"><label>模块版本</label><input type="text" name="version" value="<?php echo MODULE_VERSION;?>"></div><div class="form-group"><label>领取授权码 IP 限制（每 24 小时次数）</label><input type="number" name="ip_limit" value="<?php echo IP_LIMIT_COUNT;?>"></div><div class="form-group"><label>离线宽限时间（小时）</label><input type="number" name="offline" value="<?php echo OFFLINE_GRACE_HOURS;?>"></div><div class="form-group"><label>新管理员密码（留空则不修改）</label><input type="password" name="pwd"></div><button type="submit" name="save" class="btn btn-green">保存设置</button><button type="submit" name="backup" class="btn btn-blue" style="margin-left:12px">备份数据</button></form><?php
}
elseif ($action === 'export_auth') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="auth.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['device_code','auth_code','version','create_time','expire_time','status']);
    foreach ($codes as $v) fputcsv($out, [$v['device_code']??'',$v['auth_code']??'',$v['version']??'',date('Y-m-d H:i',$v['create_time']??0),date('Y-m-d H:i',$v['expire_time']??0),$v['status']??'']);
    fclose($out);
    exit;
}
elseif ($action === 'export_bl') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="blacklist.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['device_code','reason','add_time']);
    foreach ($bl as $k => $v) fputcsv($out, [$k,$v['reason']??'',date('Y-m-d H:i',$v['add_time']??0)]);
    fclose($out);
    exit;
}
elseif ($action === 'export_rp') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="reports.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['id','content','contact','evidence','submit_ip','submit_time','status']);
    foreach ($reports as $k => $v) fputcsv($out, [$k,$v['content']??'',$v['contact']??'',$v['evidence']??'',$v['submit_ip']??'',date('Y-m-d H:i',$v['submit_time']??0),$v['status']??'']);
    fclose($out);
    exit;
}
elseif ($action === 'logout') {
    session_destroy();
    header('Location: ?a=login');
    exit;
}
?>
</div></body></html>
