<?php
define('IN_AUTH', true);
require_once __DIR__ . '/data/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { header('Access-Control-Allow-Origin: *'); header('Access-Control-Allow-Methods: POST, OPTIONS'); header('Access-Control-Allow-Headers: Content-Type'); exit; } if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(1, 'err');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) json_out(1, 'err');
if (!check_sign($input)) json_out(1, 'err');
$dc = strtoupper(preg_replace('/[^A-Z0-9]/', '', $input['device_code'] ?? ''));
$imei = substr(preg_replace('/[^0-9]/', '', $input['imei'] ?? ''), 0, 19);
$serialno = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $input['serialno'] ?? ''), 0, 64);
if (strlen($dc) === 16) {
    add_blacklist($dc, 'copy', $serialno, $imei);
}
json_out(0, 'ok');
