<?php
define('IN_AUTH', true);
require_once __DIR__ . '/data/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { header('Access-Control-Allow-Origin: *'); header('Access-Control-Allow-Methods: POST, OPTIONS'); header('Access-Control-Allow-Headers: Content-Type'); exit; } if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(1, 'err');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) json_out(1, 'err');
if (!check_sign_sell($input)) json_out(1, 'err');
if (!ip_limit_check('report_sell', 5)) json_out(1, 'freq');
$content = xss_clean($input['content'] ?? '');
$contact = xss_clean($input['contact'] ?? '');
$evidence = xss_clean($input['evidence'] ?? '');
if (strlen($content) < 5) json_out(1, 'err');
$reports = load_data('reports.dat');
$id = count($reports) + 1;
$reports[$id] = [
    'content' => $content,
    'contact' => $contact,
    'evidence' => $evidence,
    'submit_time' => time(),
    'submit_ip' => $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
    'status' => 'pending'
];
save_data('reports.dat', $reports);
ip_limit('report_sell', 5);
json_out(0, 'ok');
