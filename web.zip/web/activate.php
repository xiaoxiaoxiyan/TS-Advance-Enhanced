<?php
define('IN_AUTH', true);
require_once __DIR__ . '/data/config.php';
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { header('Access-Control-Allow-Origin: *'); header('Access-Control-Allow-Methods: POST, OPTIONS'); header('Access-Control-Allow-Headers: Content-Type'); exit; } if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(1, 'err');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) json_out(1, 'err');
if (!check_sign($input)) json_out(1, 'err');
$dc = strtoupper(preg_replace('/[^A-Z0-9]/', '', $input['device_code'] ?? ''));
$ac = strtoupper(preg_replace('/[^A-Z0-9]/', '', $input['auth_code'] ?? ''));
if (strlen($dc) !== 16 || strlen($ac) !== 16) json_out(1, 'err');
if (is_blacklisted($dc)) json_out(1, 'err');
$imei = substr(preg_replace('/[^0-9]/', '', $input['imei'] ?? ''), 0, 19);
$serialno = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $input['serialno'] ?? ''), 0, 64);
$expect_dc = compute_device_code($imei, $serialno);
if ($expect_dc !== $dc) { add_blacklist($dc, 'device_code_mismatch', $serialno); json_out(1, 'err'); }
$codes = load_data('auth_codes.dat');
$found = false; $found_key = '';
foreach ($codes as $k => $v) {
    if ($v['auth_code'] === $ac && $v['version'] === MODULE_VERSION && $v['status'] === 'active') {
        if (empty($v['device_code']) || $v['device_code'] === $dc) {
            $found = true; $found_key = $k; break;
        }
    }
}
if (!$found) json_out(1, 'err');
/* 空白授权码首次激活时绑定到当前设备 */
if (empty($codes[$found_key]['device_code'])) {
    $codes[$found_key]['device_code'] = $dc;
    $codes[$found_key]['bind_time'] = time();
    save_data('auth_codes.dat', $codes);
}
$now = time();
$expire = $now + 86400 * 30;
$token = aes_enc(json_encode(['dc' => $dc, 'ac' => $ac, 'ver' => MODULE_VERSION, 'exp' => $expire]));
$serialno = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $input['serialno'] ?? ''), 0, 64);
$devices = load_data('devices.dat');
$devices[$dc] = ['auth_code' => $ac, 'imei' => $imei, 'serialno' => $serialno, 'activate_time' => $now, 'last_heartbeat' => $now, 'ip_history' => [$_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'], 'version' => MODULE_VERSION];
save_data('devices.dat', $devices);
json_out(0, 'ok', ['token' => $token, 'expire_time' => $expire]);
