#!/system/bin/sh
# Anlan自动救砖 - 服务阶段
# 系统成功启动后清除重启计数，并更新救砖次数描述

Disable_All_Modules() {
    ls "/data/adb/modules" | while read i; do
        [ "$i" = "$MODID" ] && continue
        touch "/data/adb/modules/$i/disable" &>/dev/null
    done
    reboot
}

Statistics() {
    if [ ! -f "$LOG" ]; then
        echo "1" > "$LOG"
    else
        Number_of_brick_rescue=$(cat "$LOG")
        p=$((Number_of_brick_rescue + 1))
        echo "$p" > "$LOG"
    fi
}

MODDIR=${0%/*}
MODID=${MODDIR##*/}
Module_XinXi="$MODDIR/module.prop"
START_LOG="$MODDIR/Number_of_starts.log"
LOG="$MODDIR/Number_of_brick_rescue.log"

# 恢复备份的 module.prop（如果有）并自删除这行（仅首次）
if [ -f "$Module_XinXi.bak" ]; then
    mv -f "$Module_XinXi.bak" "$Module_XinXi"
    sed -i '34d' "$0"
fi

sleep 180  # 等待 3 分钟，确保系统完全启动

if [ "$(getprop init.svc.bootanim)" = "stopped" ]; then
    # 开机动画已停止 -> 本次开机成功
    rm -f "$START_LOG"
    if [ -f "$LOG" ]; then
        Number_of_brick_rescue=$(cat "$LOG")
        sed -i "s/救砖次数：[0-9]*/救砖次数：$Number_of_brick_rescue/" "$Module_XinXi"
    fi
else
    # 3分钟还没进入系统 -> 卡动画了，执行救砖
    Statistics
    Disable_All_Modules
fi
exit 0