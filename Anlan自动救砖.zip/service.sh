#!/system/bin/sh
MODDIR=${0%/*}
export PATH="/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin"
/system/bin/sh "$MODDIR/Anlan_rescue2.sh"
exit 0