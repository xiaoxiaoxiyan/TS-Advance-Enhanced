#!/system/bin/sh
# Anlan自动救砖 - 第一启动阶段
# 检测连续重启次数，触发禁用所有模块

Disable_All_Modules() {
    ls "/data/adb/modules" | while read i; do
        [ "$i" = "$MODID" ] && continue
        touch "/data/adb/modules/$i/disable" &>/dev/null
    done
    reboot
}

Statistics() {
    if [ ! -f "$LOG" ]; then
        echo "1" > "$LOG"
    else
        Number_of_brick_rescue=$(cat "$LOG")
        p=$((Number_of_brick_rescue + 1))
        echo "$p" > "$LOG"
    fi
}

MODDIR=${0%/*}
MODID=${MODDIR##*/}
START_LOG="$MODDIR/Number_of_starts.log"
LOG="$MODDIR/Number_of_brick_rescue.log"

if [ ! -f "$START_LOG" ]; then
    echo 0 > "$START_LOG"
    Frequency2=1
else
    Frequency=$(cat "$START_LOG")
    Frequency2=$((Frequency + 1))
    echo "$Frequency2" > "$START_LOG"
fi

if [ "$Frequency2" -eq 2 ]; then
    # 连续两次没进系统 -> 救砖
    chmod 000 /data/adb/service.d/* /data/adb/post-fs-data.d/*
    Statistics
    Disable_All_Modules
elif [ "$Frequency2" -ge 4 ]; then
    # 极端情况强制重启
    rm -f "$START_LOG"
    Statistics
    reboot
fi
exit 0