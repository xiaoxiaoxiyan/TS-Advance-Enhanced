#!/bin/sh

until [ `getprop sys.boot_completed` -eq 1 ]
do
	sleep 1
done

echo PowerManagerService.noSuspend > /sys/power/wake_lock

cd ${0%/*}
chmod +x main.sh
./main.sh