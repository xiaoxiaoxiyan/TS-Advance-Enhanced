#!/bin/sh

Module() {
	echo "id=`basename ${0%/*}`
name=手游动态码$1
author=Heihezi
version=TG:@iOSKJZL
versionCode=101
description=QQ群:995929344 | $2" > module.prop
}


Id_Path=/data/system/users/0
rm -rf $Id_Path/registered_services $Id_Path/app_idle_stats.xml
Id_File=$Id_Path/settings_ssaid.xml
abx2xml -i $Id_File
View_id() { grep $1 $Id_File | awk -F '"' '{print $6}' ;}
Random_Id_1() { cat /proc/sys/kernel/random/uuid ;}
Amend_Id() { sed -i "s#$1#$2#g" $Id_File ;}
Amend_Id `View_id userkey` $(echo `Random_Id_1``Random_Id_1` | tr -d - | tr a-z A-Z)
Userkey_Uid=`View_id userkey`
Amend_Id `View_id com.tencent.tmgp.dfm` `Random_Id_1 | tr -d - | head -c 16`
Pkg_Aid=`View_id com.tencent.tmgp.dfm`
xml2abx -i $Id_File

Random_Id_2() {
	Min=$1
	Max=$(($2 - $Min + 1))
	Num=`cat /dev/urandom | head | cksum | awk -F ' ' '{print $1}'`
	echo $(($Num % $Max + $Min))
}
Tmp=/sys/devices/virtual/kgsl/kgsl/full_cache_threshold
Random_Id_2 1100000000 2000000000 > $Tmp
mount | grep -q /sys/devices/soc0/serial_number && umount /sys/devices/soc0/serial_number
mount --bind $Tmp /sys/devices/soc0/serial_number

IFS=$'\n'
for i in `getprop | grep imei | awk -F '[][]' '{print $2}'`
do
	Imei=`getprop $i`
	[ `echo $Imei | wc -c` -lt 16 ] && continue
	let a++
	resetprop $i `echo $((RANDOM % 80000 + 8610000))00000000`
done

echo `Random_Id_1 | tr -d - | head -c 16` > /data/system/oaid_persistence_0

echo `Random_Id_1 | tr -d - | head -c 16` > /data/system/vaid_persistence_platform

resetprop ro.serialno `Random_Id_1 | head -c 8`

settings put secure android_id `Random_Id_1 | tr -d - | head -c 16`

settings put secure bluetooth_address `Random_Id_1 | sed 's/-//g ;s/../&:/g' | head -c 17 | tr a-z A-Z`

resetprop ro.build.id UKQ1.$((RANDOM % 20000 + 30000)).001

resetprop ro.boot.cpuid 0x00000`Random_Id_1 | tr -d - | head -c 11`

resetprop ro.ril.oem.meid 9900$((RANDOM % 8000000000 + 1000000000))

settings put global ad_aaid `Random_Id_1`

settings put global extm_uuid `Random_Id_1`

settings put system key_mqs_uuid `Random_Id_1`

Sum=`getprop ro.build.fingerprint`
for i in $(seq 1 `echo "$Sum" | grep -o [0-9] | wc -l`)
do
	Sum=`echo "$Sum" | sed "s/[0-9]/$(($RANDOM % 10))/$i"`
done
resetprop ro.build.fingerprint "$Sum"

mount | grep -q /sys/class/net/wlan0/address && umount /sys/class/net/wlan0/address
svc wifi disable
ifconfig wlan0 down
Mac=`Random_Id_1 | sed 's/-//g ;s/../&:/g' | head -c 17`
ifconfig wlan0 hw ether $Mac
for Wlan_Path in `find /sys/devices -name wlan0`
do
	[ -f "$Wlan_Path/address" ] && {
		chmod 644 "$Wlan_Path/address"
		echo $Mac > "$Wlan_Path/address"
	}
done
chmod 0755 /sys/class/net/wlan0/address
echo $Mac > /sys/class/net/wlan0/address
for Wlan_Path in `find /sys/devices -name '*,wcnss-wlan'`
do
	[ -f "$Wlan_Path/wcnss_mac_addr" ] && {
		chmod 644 "$Wlan_Path/wcnss_mac_addr"
		echo $Mac > "$Wlan_Path/wcnss_mac_addr"
	}
done
echo $Mac > /data/local/tmp/Mac_File
mount --bind /data/local/tmp/Mac_File /sys/class/net/wlan0/address
ifconfig wlan0 up
svc wifi enable

until ping -c 1 223.5.5.5 &>/dev/null
do
	sleep 1
done

echo $((`cat Ping` + 1)) > Ping
Module " #已自动修改`cat Ping`次"  "IP地址: `curl -s ipinfo.io/ip` 主板ID: `cat /sys/devices/soc0/serial_number` 序列号: `getprop ro.serialno` Wifi_Mac地址: `cat /sys/class/net/wlan0/address` 设备ID: `settings get secure android_id` OAID: `cat /data/system/oaid_persistence_0` 三角洲AID: $Pkg_Aid IMEI已重置 蓝牙Mac地址: `settings get secure bluetooth_address` CPU_ID: `getprop ro.boot.cpuid` VAID: `cat /data/system/vaid_persistence_platform` 版本ID: `getprop ro.build.id` OEM_ID: `getprop ro.ril.oem.meid` 广告ID: `settings get global ad_aaid` UUID: `settings get global extm_uuid` 指纹UUID: `settings get system key_mqs_uuid` 系统UUID: $Userkey_Uid"