#!/system/bin/sh

passpropstate() {
  check_missing_match_prop() {
    local NAME=$1
    local EXPECTED=$2
    local VALUE=$(getprop $NAME)
    [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop $NAME $EXPECTED
    [ -z $VALUE ] && resetprop $NAME $EXPECTED
  }
  contains_reset_prop() {
    local NAME=$1
    local CONTAINS=$2
    local NEWVAL=$3
    [[ "$(getprop $NAME)" = *"$CONTAINS"* ]] && resetprop $NAME $NEWVAL
  }
  check_missing_prop() {
    local NAME=$1
    local EXPECTED=$2
    local VALUE=$(getprop $NAME)
    [ -z $VALUE ] && resetprop $NAME $EXPECTED
  }
  check_reset_prop() {
    local NAME=$1
    local EXPECTED=$2
    local VALUE=$(getprop $NAME)
    [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop $NAME $EXPECTED
  }
  vbmeta_size="$(busybox blockdev --getbsz "/dev/block/by-name/vbmeta"$(getprop ro.boot.slot_suffix)"")"; [ -n "$vbmeta_size" ] || vbmeta_size="4096"
  resetprop "sys.usb.adb.disabled" " "
  check_missing_match_prop "ro.boot.vbmeta.device_state" "locked"
  check_missing_match_prop "ro.boot.verifiedbootstate" "green"
  check_missing_match_prop "ro.boot.veritymode" "enforcing"
  check_missing_match_prop "ro.boot.warranty_bit" "0"
  check_missing_match_prop "ro.boot.flash.locked" "1"
  contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"
  contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
  contains_reset_prop "ro.bootmode" "recovery" "unknown"
  check_missing_prop "ro.boot.vbmeta.invalidate_on_error" yes
  check_missing_prop "ro.boot.vbmeta.size" "$vbmeta_size"
  check_missing_prop "ro.boot.vbmeta.hash_alg" "sha256"
  check_missing_prop "ro.boot.vbmeta.avb_version" "1.2"
  check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
  check_reset_prop "vendor.boot.verifiedbootstate" "green"
  check_reset_prop "ro.secureboot.lockstate" "locked"
  check_reset_prop "ro.boot.realmebootstate" "green"
  check_reset_prop "ro.vendor.boot.warranty_bit" "0"
  check_reset_prop "sys.oem_unlock_allowed" "0"
  check_reset_prop "ro.boot.realme.lockstate" "1"
  check_reset_prop "ro.build.tags" "release-keys"
  check_reset_prop "ro.crypto.state" "encrypted"
  check_reset_prop "ro.vendor.warranty_bit" "0"
  check_reset_prop "ro.force.debuggable" "0"
  check_reset_prop "ro.build.type" "user"
  check_reset_prop "ro.warranty_bit" "0"
  check_reset_prop "ro.debuggable" "0"
  check_reset_prop "ro.kernel.qemu" ""
  check_reset_prop "ro.adb.secure" "1"
  check_reset_prop "ro.secure" "1"
  
}

passpropstate