#!/system/bin/sh

: "${MODPATH:=}"

WC="/data/adb/微微微"
TSKEY="/data/adb/tricky_store/keybox.xml"
TS="$MODPATH/modules/Tricky-Store.zip"

# 音量键检测
volume() {
    local key_click=""
    
    while [ "$key_click" = "" ]; do
        key_event=$(getevent -lqc 1 2>/dev/null | grep -E "KEY_VOLUMEUP|KEY_VOLUMEDOWN")
        
        if echo "$key_event" | grep -q "KEY_VOLUMEUP"; then
            key_click="UP"
        elif echo "$key_event" | grep -q "KEY_VOLUMEDOWN"; then
            key_click="DOWN"
        fi
        
        if [ -n "$key_click" ]; then
            sleep 0.2
        fi
    done
    echo "$key_click"
}

install_module() {
    local module="$1"
    local name="$2"
    
    if [ ! -f "$module" ]; then
        ui_print "模块文件不存在: $module"
        return 1
    fi
    
    ui_print "[+]正在刷入[$name]"
    
    # 尝试 Magisk
    if command -v magisk; then
        if magisk --install-module "$module"; then
            ui_print "安装成功: $name (Magisk)"
            return 0
        fi
    fi
    
    # 尝试 KSU Classic (kernelsu/ksud)
    if command -v kernelsu; then
        if kernelsu --install-module "$module"; then
            ui_print "安装成功: $name (KSU Classic)"
            return 0
        fi
    fi
    
    if command -v ksud; then
        if ksud module install "$module"; then
            ui_print "安装成功: $name (KSU)"
            return 0
        fi
    fi
    
    if [ -f "/data/adb/ksud" ]; then
        if /data/adb/ksud module install "$module"; then
            ui_print "安装成功: $name (KSU Next)"
            return 0
        fi
    fi
    
    # 尝试 APatch
    if [ -f "/data/adb/apd" ]; then
        if /data/adb/apd module install "$module"; then
            ui_print "安装成功: $name (APatch)"
            return 0
        fi
    fi
    
    if command -v apd; then
        if apd module install "$module"; then
            ui_print "安装成功: $name (APatch)"
            return 0
        fi
    fi
    
    ui_print "安装失败: $name (所有方式都失败)"
    return 1
}

monitor_root() {
    ENV_DETECTED=""

    set -- \
        "/system/bin/resetprop" \
        "/system_ext/bin/resetprop" \
        "/product/bin/resetprop" \
        "/data/adb/ksu/bin/resetprop" \
        "/data/adb/ap/bin/resetprop"

    for path in "$@"; do
        if [ -f "$path" ] && [ -x "$path" ]; then
            RESETPROP_BIN="$path"
            ui_print "正在遍历路径..."
            sleep 0.5
        
            case "$path" in
                "/system/bin/resetprop")
                    ui_print "成功识别德尔塔/金丝雀"
                    ENV_DETECTED="magisk"
                    ;;
                "/system_ext/bin/resetprop")
                    ui_print "成功识别阿尔法(旧版)"
                    ENV_DETECTED="magisk"
                    ;;
                "/product/bin/resetprop")
                    ui_print "成功识别Magisk/阿尔法(新版)"
                    ENV_DETECTED="magisk"
                    ;;
                "/data/adb/ksu/bin/resetprop")
                    ui_print "成功识别KernelSU/Wild KSU/SukiSU Ultra"
                    ENV_DETECTED="ksu"
                    ;;
                "/data/adb/ap/bin/resetprop")
                    ui_print "成功识别APatch/FolkPatch"
                    ENV_DETECTED="apatch"
                    ;;
            esac
        
            sleep 0.3
            break
        fi
    done

    if [ -z "$RESETPROP_BIN" ]; then
        ui_print "未找到 resetprop，无法识别环境"
    fi
}

keykey() {
    if [ ! -f "$TSKEY" ]; then
        ui_print "TS模块疑似刷入失败，找不到 $TSKEY"
        return 1
    fi
    
    if [ -f "$MODPATH/key/keybox.xml" ]; then
        mv -f "$MODPATH/key/keybox.xml" "$TSKEY" || ui_print "错误：密钥替换失败"
        ui_print "[✔︎]已执行替换有效密钥操作"
    else
        ui_print "源密钥文件不存在: $MODPATH/key/keybox.xml"
    fi

}

# 模块声明
clear
ui_print "***********************************"
ui_print
ui_print "      微微微-环境辅助模块安装 😋          "
ui_print
ui_print "***********************************"
ui_print "安装时间: $(date)"
ui_print "设备型号: $(getprop ro.product.model)"
ui_print "安卓版本: $(getprop ro.build.version.release)"
ui_print "内核版本: $(uname -r)"
ui_print "序列号: $(getprop ro.boot.serialno)"
ui_print "***********************************"

# 创建目录结构
mkdir -p "$WC" 2>/dev/null
mkdir -p "$WC/config" 2>/dev/null
mkdir -p "$MODPATH" 2>/dev/null
mkdir -p "$MODPATH/scripts" 2>/dev/null

if [ $? -ne 0 ]; then
    ui_print "[✘]错误: 创建目录失败，请检查权限"
fi
ui_print "[✔︎]目录创建成功"

# 设置权限
set_perm_recursive "$MODPATH" 0 0 0700 0600
set_perm "$MODPATH/service.sh" 0 0 0700
set_perm "$MODPATH/scripts/*.sh" 0 0 0700
ui_print "[✔︎]权限设置完毕"

ui_print "***********************************"
ui_print "开机自动处理项——功能选项"
ui_print "***********************************"
ui_print "[+]是否启用动态码 | 开机随机设备ID"
ui_print "按【音量上】：启用该功能"
ui_print "按【音量下】：禁用该功能"
keyid=$(volume)
case "$keyid" in
    "UP")
        ui_print "▶已启用动态码功能"
        ;;
    "DOWN")
        ui_print "▶已禁用动态码功能"
        rm -f "$MODPATH/scripts/device_ID.sh" 2>/dev/null
        ;;
esac
ui_print "***********************************"
ui_print "[+]是否自动关闭开发者+USB调试"
ui_print "[+]注：一加解锁BL后USB调试会默认开启"
ui_print "按【音量上】：启用该功能"
ui_print "按【音量下】：禁用该功能"
key3=$(volume)
case "$key3" in
    "UP")
        ui_print "▶已启用自动关闭开发者+USB调试"
        ;;
    "DOWN")
        ui_print "▶已禁用自动关闭开发者+USB调试"
        rm -f "$MODPATH/scripts/development_adb.sh" 2>/dev/null
        ;;
esac
ui_print "***********************************"
ui_print "[+]是否自动设置MT管理器的MT2路径"
ui_print "按【音量上】：启用该功能"
ui_print "按【音量下】：禁用该功能"
key8=$(volume)
case "$key8" in
    "UP")
        ui_print "▶已启用MT2路径自动修改"
        ;;
    "DOWN")
        ui_print "▶已禁用MT2路径自动修改"
        rm -f "$MODPATH/scripts/mt.xml.sh" 2>/dev/null
        ;;
esac
auto() {
ui_print "***********************************"
ui_print "[+]是否自动排除AP或FP应用列表"
ui_print "按【音量上】：启用该功能"
ui_print "按【音量下】：禁用该功能"
key7=$(volume)
case "$key7" in
    "UP")
        ui_print "▶已启用AP/FP自动排除应用"
        ;;
    "DOWN")
        ui_print "▶已禁用AP/FP自动排除应用"
        rm -f "$MODPATH/scripts/auto_exclude.sh" 2>/dev/null
        ;;
esac
}
[ -d /data/adb/ap ] && auto
[ -d /data/adb/ap ] && rm -f "$MODPATH/scripts/auto_exclude.sh" 2>/dev/null
ui_print "***********************************"
ui_print "[+]是否自动清理设备环境残留"
ui_print "按【音量上】：启用该功能"
ui_print "按【音量下】：禁用该功能"
key9=$(volume)
case "$key9" in
    "UP")
        ui_print "▶已启用自动清理残留"
        ;;
    "DOWN")
        ui_print "▶已禁用自动清理残留"
        rm -f "$MODPATH/scripts/environment.sh" 2>/dev/null
        ;;
esac
ui_print "***********************************"
ui_print "[+]是否启用性能优化 | 修改系统属性以提升性能"
ui_print "按【音量上】：启用该功能"
ui_print "按【音量下】：禁用该功能"
key6=$(volume)
case "$key6" in
    "UP")
        ui_print "▶已启用性能优化"
        ;;
    "DOWN")
        ui_print "▶已禁用性能优化"
        rm -f "$MODPATH/scripts/optimize_system.sh" 2>/dev/null
        ;;
esac
ui_print "***********************************"
ui_print "[+]是否启用修改系统属性锁定BL状态"
ui_print "[+]天玑可单弱隐 | TS必选此功能 | 免解勿选"
ui_print "按【音量上】：启用该功能"
ui_print "按【音量下】：禁用该功能"
keybl=$(volume)
case "$keybl" in
    "UP")
        ui_print "▶已启用弱隐BL功能"
        ;;
    "DOWN")
        ui_print "▶已禁用弱隐BL功能"
        rm -f "$MODPATH/post-fs-data.sh" 2>/dev/null
        ;;
esac
ui_print "***********************************"
ui_print "[+]最后——是否刷入TS模块解决TEE&密钥"
ui_print "[+]注：本模块仅在系统启动时自动刷新包名"
ui_print "[+]注：借助自启模块可做到实时刷新包名"
ui_print "按【音量上】：是的，我需要"
ui_print "按【音量下】：不要，我不用"
key4=$(volume)
case "$key4" in
    "UP")
        ui_print "▶为设备刷入TS和TSEE模块"
        ui_print "***********************************"
        monitor_root
        install_module "$TS" "Tricky-Store-v1.4.1-248"
        ui_print "[✔︎]隐藏模块已刷入完毕"
        sleep 0.2
        keykey
        sleep 0.2
        ;;
    "DOWN")
        ui_print "▶正在移除内置的TS模块"
        ;;
esac
rm -rf "$MODPATH/modules" "$MODPATH/key" 2>/dev/null
ui_print "***********************************"
ui_print "这真是我梦寐以求的模块！我要支持微微微！！"
ui_print "想要立刻跳转群聊，支持作者嘛？"
ui_print "😘 按【音量上】：很愿意"
ui_print "😅 按【音量下】：才不要"
ui_print "***********************************"
ui_print "感谢使用微的模块"
ui_print "微微微将为您提供更好内核体验"
ui_print "𝗖𝗶𝗮𝗹𝗹𝗼～(∠・ω< )⌒☆"
ui_print "***********************************"
key1=$(volume)
case "$key1" in
    "UP")
        
        ui_print "对的对的(≧∇≦)ﾉ"
        ui_print "🥰太棒了，您做出了最正确的选择！"
        ui_print "***********************************"
        ;;
    "DOWN")
        ui_print "呜呜呜→)╥﹏╥)"
        ui_print "😭太坏了，祝你上厕所没有纸！！！"
        ui_print "***********************************"
        ;;
esac