#!/system/bin/sh

MODDIR="/data/adb/modules/www_envhide"
TS="/data/adb/modules/tricky_store"
TARGET="/data/adb/tricky_store/target.txt"
WC="/data/adb/微微微"

# 音量键检测
volume() {
    local key_click=""
    
    while [ "$key_click" = "" ]; do
        key_event=$(getevent -lqc 1 2>/dev/null | grep -E "KEY_VOLUMEUP|KEY_VOLUMEDOWN")
        
        if echo "$key_event" | grep -q "KEY_VOLUMEUP"; then
            key_click="UP"
        elif echo "$key_event" | grep -q "KEY_VOLUMEDOWN"; then
            key_click="DOWN"
        fi
        
        if [ -n "$key_click" ]; then
            sleep 0.2
        fi
    done
    echo "$key_click"
}

clear
echo "===============| 快捷服务 |================="
echo
echo "   [音量➕] >>> | 一键更新TS包名列表 |"
echo
echo "   [音量➖] >>> | 一键清理和修改ID | "
echo
echo "========================================="
key1=$(volume)
case "$key1" in
    "UP")
        sleep 0.2
        echo
        if [ ! -d "$TS" ]; then
            echo "▶未检测到TS模块，无法更新包名"
            sleep 1
            exit 1
        fi
        pm list packages -3 | sed 's/^package://' > "$TARGET" 2>/dev/null
        echo "▶已更新TS应用包名列表"
        echo
        echo "▶感谢使用微的模块 𝗖𝗶𝗮𝗹𝗹𝗼～(∠・ω< )⌒☆"
        echo
        echo "========================================="
        sleep 1
        exit 0
        ;;
    "DOWN")
        sleep 0.2
        echo
        echo "▶正在修改应用和设备ID同时清理游戏与设备残留"
        /system/bin/sh "$MODDIR/scripts/clear.sh" >/dev/null 2>&1
        echo
        echo "▶感谢使用微的模块 𝗖𝗶𝗮𝗹𝗹𝗼～(∠・ω< )⌒☆"
        echo
        echo "========================================="
        exit 0
        ;;
esac
