#!/system/bin/sh

MODDIR="/data/adb/modules/www_envhide"
TS="/data/adb/modules/tricky_store"
TARGET="/data/adb/tricky_store/target.txt"

# 主函数
main() {
    # 清理权限
    chmod -R 0700 /data/adb 2>/dev/null
    
    # 等待开机
    until [ "$(getprop sys.boot_completed)" -eq 1 ]; do
        sleep 2
    done
    
    # 刷新TS包名
    [ -d "$TS" ] && pm list packages -3 | sed 's/^package://' > "$TARGET" 2>/dev/null
    
    # 自启接管
    [ -d "/data/adb/modules/kernel_trigger" ] && exit 0
    
    # 执行功能
    /system/bin/sh "$MODDIR/scripts/auto_exclude.sh" >/dev/null 2>&1
    /system/bin/sh "$MODDIR/scripts/environment.sh" >/dev/null 2>&1
    /system/bin/sh "$MODDIR/scripts/mt.xml.sh" >/dev/null 2>&1
    /system/bin/sh "$MODDIR/scripts/device_ID.sh" >/dev/null 2>&1
    /system/bin/sh "$MODDIR/scripts/optimize_system.sh" >/dev/null 2>&1
    /system/bin/sh "$MODDIR/scripts/development_adb.sh" >/dev/null 2>&1
    # 清理日志痕迹
    logcat -c
    
    exit 0
}

main
