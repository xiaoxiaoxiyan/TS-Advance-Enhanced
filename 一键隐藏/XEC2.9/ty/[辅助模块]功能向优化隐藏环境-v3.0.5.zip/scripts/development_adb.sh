#!/system/bin/sh

TMP_DIR="/dev/kt_tmp"
LOGFILE="$TMP_DIR/operation.log"

# 日志函数
log() {
    if [ ! -f "$LOGFILE" ]; then
        mkdir -p "$TMP_DIR" && touch "$LOGFILE" 2>/dev/null
        chmod 600 -R "$TMP_DIR" 2>/dev/null
    fi
    
    echo "[辅助] $*" >> "$LOGFILE"
}

sleep 3

{
cmd settings put global adb_enabled 0
cmd settings put secure adb_enabled 0
stop adbd
cmd settings put global development_settings_enabled 0
} 2>/dev/null

log "✔︎关闭开发者+USB调试"

exit 0