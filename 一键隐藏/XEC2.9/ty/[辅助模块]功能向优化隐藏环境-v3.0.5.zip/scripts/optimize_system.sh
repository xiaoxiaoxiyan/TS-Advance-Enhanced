#!/system/bin/sh

TMP_DIR="/dev/kt_tmp"
LOGFILE="$TMP_DIR/operation.log"

# 日志函数
log() {
    if [ ! -f "$LOGFILE" ]; then
        mkdir -p "$TMP_DIR" && touch "$LOGFILE" 2>/dev/null
        chmod 600 -R "$TMP_DIR" 2>/dev/null
    fi
    
    echo "[辅助] $*" >> "$LOGFILE"
}

{
# 内存优化
echo "10" > /proc/sys/vm/swappiness
echo "50" > /proc/sys/vm/vfs_cache_pressure
echo "5" > /proc/sys/vm/dirty_background_ratio
echo "10" > /proc/sys/vm/dirty_ratio
# 网络优化
echo "1" > /proc/sys/net/ipv4/tcp_timestamps
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse
echo "30" > /proc/sys/net/ipv4/tcp_fin_timeout
# 环境优化
echo 16384 > /proc/sys/fs/inotify/max_queued_events
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 8192 > /proc/sys/fs/inotify/max_user_watches
# 强制启用4xMSAA
setprop debug.egl.force_msaa true
setprop debug.egl.msaa 4
setprop debug.hwui.renderer skiagl
setprop debug.hwui.disable_hw_renderer false
setprop debug.egl.hw_msaa 1
setprop debug.gralloc.enable_fb_ubwc 0
# 停用HW叠加层
setprop debug.hwui.disable_hw_overlays true
setprop debug.sf.disable_hwcomposer 1
setprop debug.composition.type gpu
setprop debug.hwui.fbo_cache_size 0
# 应用到设置
settings put global force_gpu_rendering 1
settings put global disable_hw_overlays 1
service call SurfaceFlinger 1008 i32 1

} 2>/dev/null

log "✔︎优化系统参数性能"

exit 0