#!/system/bin/sh

TMP_DIR="/dev/kt_tmp"
LOGFILE="$TMP_DIR/operation.log"

# 日志函数
log() {
    if [ ! -f "$LOGFILE" ]; then
        mkdir -p "$TMP_DIR" && touch "$LOGFILE" 2>/dev/null
        chmod 600 -R "$TMP_DIR" 2>/dev/null
    fi
    
    echo "[辅助] $*" >> "$LOGFILE"
}

{
if [ ! -f "/data/user/0/bin.mt.plus.canary/shared_prefs/bin.mt.plus.canary_preferences.xml" ] && [ ! -f "/data/user/0/bin.mt.plus/shared_prefs/bin.mt.plus_preferences.xml" ]; then
    exit 1
fi

[ -f "/data/user/0/bin.mt.plus.canary/shared_prefs/bin.mt.plus.canary_preferences.xml" ] && cat > /data/user/0/bin.mt.plus.canary/shared_prefs/bin.mt.plus.canary_preferences.xml << 'EOF'
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <boolean name="apk_installation_shizuku" value="true" />
    <boolean name="optimize_external_storage_dt" value="true" />
    <boolean name="deletion_warning" value="true" />
    <string name="load_path_left">0</string>
    <string name="mt2_path">/sdcard/</string>
    <boolean name="apk_installation_prevents_deletion" value="false" />
    <boolean name="show_input_fav" value="true" />
    <boolean name="apk_installation_dhizuku" value="true" />
    <boolean name="network_thumb_enable" value="true" />
    <string name="auto_clean_recycle_bin">0</string>
    <string name="bottom_toolbar_padding_type">0</string>
    <boolean name="enable_recycle_bin" value="false" />
    <string name="date_time_format">0</string>
    <boolean name="apk_installation_confirm" value="false" />
    <boolean name="use_external_storage_api" value="false" />
    <string name="custom_language">auto</string>
    <boolean name="apk_installation_root" value="true" />
    <boolean name="network_thumb_only_load_on_wifi" value="true" />
    <boolean name="preserve_file_time" value="true" />
    <boolean name="external_storage_thumb_enable" value="true" />
    <string name="load_path_right">0</string>
    <boolean name="def_mov_recycle_bin" value="true" />
    <boolean name="show_bookmarks_in_sidebar" value="false" />
    <string name="file_list_size">1</string>
    <boolean name="apk_installation_verify" value="true" />
    <boolean name="disable_permission_in_list" value="false" />
    <boolean name="generate_backup_file" value="false" />
    <boolean name="get_root" value="true" />
    <boolean name="get_adb" value="true" />
    <boolean name="bookmark_swipe_pos_aware" value="false" />
    <string name="last_shell_backend">root</string>
    <string name="file_name_max_line">2</string>
</map>

EOF

[ -f "/data/user/0/bin.mt.plus/shared_prefs/bin.mt.plus_preferences.xml" ] && cat > /data/user/0/bin.mt.plus/shared_prefs/bin.mt.plus_preferences.xml << 'EOF'
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <boolean name="apk_installation_shizuku" value="true" />
    <boolean name="optimize_external_storage_dt" value="true" />
    <boolean name="deletion_warning" value="true" />
    <string name="load_path_left">0</string>
    <string name="mt2_path">/sdcard/</string>
    <boolean name="apk_installation_prevents_deletion" value="false" />
    <boolean name="show_input_fav" value="true" />
    <boolean name="apk_installation_dhizuku" value="true" />
    <boolean name="network_thumb_enable" value="true" />
    <string name="auto_clean_recycle_bin">0</string>
    <string name="bottom_toolbar_padding_type">0</string>
    <boolean name="enable_recycle_bin" value="false" />
    <string name="date_time_format">0</string>
    <boolean name="apk_installation_confirm" value="false" />
    <boolean name="use_external_storage_api" value="false" />
    <string name="custom_language">auto</string>
    <boolean name="apk_installation_root" value="true" />
    <boolean name="network_thumb_only_load_on_wifi" value="true" />
    <boolean name="preserve_file_time" value="true" />
    <boolean name="external_storage_thumb_enable" value="true" />
    <string name="load_path_right">0</string>
    <boolean name="def_mov_recycle_bin" value="true" />
    <boolean name="show_bookmarks_in_sidebar" value="false" />
    <string name="file_list_size">1</string>
    <boolean name="apk_installation_verify" value="true" />
    <boolean name="disable_permission_in_list" value="false" />
    <boolean name="generate_backup_file" value="false" />
    <boolean name="get_root" value="true" />
    <boolean name="get_adb" value="true" />
    <boolean name="bookmark_swipe_pos_aware" value="false" />
    <string name="last_shell_backend">root</string>
    <string name="file_name_max_line">2</string>
</map>

EOF

} 2>/dev/null

log "✔︎修改MT2路径设置"

exit 0