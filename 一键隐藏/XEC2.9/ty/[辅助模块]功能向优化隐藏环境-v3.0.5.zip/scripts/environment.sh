#!/system/bin/sh

TMP_DIR="/dev/kt_tmp"
LOGFILE="$TMP_DIR/operation.log"

# 日志函数
log() {
    if [ ! -f "$LOGFILE" ]; then
        mkdir -p "$TMP_DIR" && touch "$LOGFILE" 2>/dev/null
        chmod 600 -R "$TMP_DIR" 2>/dev/null
    fi
    
    echo "[辅助] $*" >> "$LOGFILE"
}

{
# 系统缓存清理
rm -rf /data/cache/*
rm -rf /cache/*
rm -rf /data/anr/*
rm -rf /tmp/*
rm -rf /data/tombstones/*
rm -rf /data/system/dropbox/*
rm -rf /data/system/graphicsstats
rm -rf /data/system/package_cache
rm -rf /data/misc/iopgp
rm -rf /data/local/tmp/*
find /data -name "*.tmp" -delete 2>/dev/null
find /data -name "*.temp" -delete 2>/dev/null
# 模块/驱动残留
rm -rf /dev/Bing/
rm -rf /data/BingHPJY/
rm -rf /data/BingPUBG
rm -rf /data/jz/
rm -rf /data/jz.sh
rm -rf /data/.gamepad_driver_installed
rm -rf /data/system/xydriver.ko
rm -rf /data/system/liborangeinit.so
rm -rf /data/system/liboxmem.so
rm -rf /system/lib/hid/gamepad_driver.so
rm -rf /data/local/tmp/gamepad_driver.so
rm -rf /data/gamepad_driver.so
rm -rf /data/nh.ko
rm -rf /data/nh/
rm -rf /data/nh2/
rm -rf /data/nh3/
rm -rf /data/nh4/
rm -rf /data/nh5/
rm -rf /data/nh6/
rm -rf /data/HPX/
rm -rf /data/system/HPX/
rm -rf /data/HPY/
rm -rf /data/system/HPY/
rm -rf /dev/kt_tmp/kt_*
rm -rf /data/property/
# 应用数据清理 - ROOT工具相关
rm -rf /storage/emulated/*/Android/data/me.garfieldhan.holmes
rm -rf /storage/emulated/*/Android/data/com.zhenxi.hunter
rm -rf /storage/emulated/*/Android/data/icu.nullptr.nativetest
rm -rf /storage/emulated/*/Android/data/com.byyoung.setting
rm -rf /storage/emulated/*/Android/data/bin.mt.plus
rm -rf /storage/emulated/*/Android/data/bin.mt.plus.canary
rm -rf /storage/emulated/*/Android/data/com.omarea.vtools
rm -rf /storage/emulated/*/Android/data/moe.shizuku.privileged.api
rm -rf /storage/emulated/*/Android/data/io.github.vvb2060.mahoshojo
rm -rf /storage/emulated/*/Android/data/icu.nullptr.applistdetector
rm -rf /storage/emulated/*/Android/data/com.byxiaorun.detector
rm -rf /storage/emulated/*/Android/data/io.github.huskydg.memorydetector
rm -rf /storage/emulated/*/Android/data/com.OrangeEnvironment.Detector
rm -rf /storage/emulated/*/Android/data/com.Longze.detector.pro2
rm -rf /storage/emulated/*/Android/data/rikka.safetynetchecker
rm -rf /storage/emulated/*/Android/data/io.github.vvb2060.keyattestation
rm -rf /storage/emulated/*/Android/data/org.telegram.messenger.web
rm -rf /storage/emulated/*/Android/data/com.tencent.mobileqq/cache/share
rm -rf /storage/emulated/*/Android/data/com.apocalua.run/
rm -rf /mnt/pass_through/10/emulated/*/Android/data/bin.mt.plus.canary
rm -rf /storage/emulated/legacy/Android/data/com.apocalua.run/
# OBB数据清理
rm -rf /storage/emulated/*/Android/obb/io.github.vvb2060.mahoshojo
rm -rf /storage/emulated/*/Android/obb/icu.nullptr.applistdetector
rm -rf /storage/emulated/*/Android/obb/com.byxiaorun.detector
rm -rf /storage/emulated/*/Android/obb/io.github.huskydg.memorydetector
rm -rf /storage/emulated/*/Android/obb/com.OrangeEnvironment.Detector
rm -rf /storage/emulated/*/Android/obb/com.Longze.detector.pro2
rm -rf /storage/emulated/*/Android/obb/rikka.safetynetchecker
rm -rf /storage/emulated/*/Android/obb/io.github.vvb2060.keyattestation
# Media目录清理
rm -rf /storage/emulated/*/Android/media/org.telegram.messenger.web
rm -rf /storage/emulated/*/Android/media/io.github.vvb2060.mahoshojo
rm -rf /storage/emulated/*/Android/media/icu.nullptr.applistdetector
rm -rf /storage/emulated/*/Android/media/com.byxiaorun.detector
rm -rf /storage/emulated/*/Android/media/io.github.huskydg.memorydetector
rm -rf /storage/emulated/*/Android/media/com.OrangeEnvironment.Detector
rm -rf /storage/emulated/*/Android/media/com.Longze.detector.pro2
rm -rf /storage/emulated/*/Android/media/rikka.safetynetchecker
rm -rf /storage/emulated/*/Android/media/io.github.vvb2060.keyattestation
# 用户目录清理
rm -rf /storage/emulated/*/MT2
rm -rf /storage/emulated/*/WechatXposed
rm -rf /storage/emulated/*/Download/WechatXposed
rm -rf /storage/emulated/*/Wec
rm -rf /storage/emulated/*/落叶配置
rm -rf /storage/emulated/*/BY物资
rm -rf /sdcard/elgg/
rm -rf /storage/emulated/elgg/
rm -rf /data/local/tmp/byyang/
rm -rf /data/local/tmp/shizuku
rm -rf /data/local/tmp/shizuku_starter
# 其他应用数据
rm -rf /data/user/*/com.juom

} 2>/dev/null

log "✔︎清理环境各项残留"

exit 0