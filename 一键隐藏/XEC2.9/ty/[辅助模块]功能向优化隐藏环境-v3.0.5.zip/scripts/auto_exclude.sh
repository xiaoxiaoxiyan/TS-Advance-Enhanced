#!/system/bin/sh

TMP_DIR="/dev/kt_tmp"
LOGFILE="$TMP_DIR/operation.log"

# 日志函数
log() {
    if [ ! -f "$LOGFILE" ]; then
        mkdir -p "$TMP_DIR" && touch "$LOGFILE" 2>/dev/null
        chmod 600 -R "$TMP_DIR" 2>/dev/null
    fi
    
    echo "[辅助] $*" >> "$LOGFILE"
}

{
# 检测ap/fp
[ -f "/data/adb/ap/package_config" ] || exit 1

# 提取Root应用包名
root_list="$(grep -F "u:r:magisk:s0" /data/adb/ap/package_config)"

# 跳过包名列表
skip_pkg="
me.bmax.apatch
me.yuki.folk
mi.yuki.folk
fp.wc
yf.wc
"

# Root包名列表
force_root_pkg="
bin.mt.plus
bin.mt.plus.canary
com.omarea.vtools
"

# 生成配置
{
    echo "pkg,exclude,allow,uid,to_uid,sctx"
    [ -n "$root_list" ] && echo "$root_list"
    
    while read -r line; do
        pkg=$(echo "$line" | sed 's/^package://; s/ uid:.*//')
        uid=$(echo "$line" | sed 's/.*uid://')
        
        # 跳过特定包名
        echo "$skip_pkg" | grep -qxF "$pkg" && continue
        # 跳过已有Root权限的
        echo "$root_list" | grep -q "^$pkg," && continue
        
        # 强制Root
        if echo "$force_root_pkg" | grep -qxF "$pkg"; then
            echo "$pkg,0,1,$uid,0,u:r:magisk:s0"
        else
            echo "$pkg,1,0,$uid,0,u:r:untrusted_app:s0"
        fi
    done << EOF
$(pm list packages -3 -U)
EOF
} > /data/adb/ap/package_config

} 2>/dev/null

log "✔︎排除AP/FP应用列表"

exit 0
