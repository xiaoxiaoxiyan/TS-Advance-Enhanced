#!/system/bin/sh

{
# 清理iptables规则
iptables -F
iptables -X 
iptables -Z
iptables -t nat -F 
iptables -F

# 初始化IP
INTERFACE="wlan0"
IP=$(ip addr show $INTERFACE | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | cut -d/ -f1)
IP_PREFIX=$(echo $IP | cut -d. -f1-3)
NEW_IP_LAST_PART1=$(($RANDOM % 254 + 1))
NEW_IP_LAST_PART2=$(($RANDOM % 254 + 1))
NEW_IP1="${IP_PREFIX}.${NEW_IP_LAST_PART1}"
NEW_IP2="${IP_PREFIX}.${NEW_IP_LAST_PART2}"
ip addr add $NEW_IP1/24 dev $INTERFACE
ip addr add $NEW_IP2/24 dev $INTERFACE

# 修改序列号
name=$(tr -dc '1-9' < /dev/urandom | head -c 8)
while echo "$name" | grep -q "'"
do
name=$(tr -dc '1-9' < /dev/urandom | head -c 8)
done 
resetprop ro.serialno $name

# 修改系统UUID和应用AID
Id_Path=/data/system/users/0
rm -rf $Id_Path/registered_services $Id_Path/app_idle_stats.xml
Id_File=$Id_Path/settings_ssaid.xml
abx2xml -i $Id_File

View_id() { grep $1 $Id_File | awk -F '"' '{print $6}' ;}
Random_Id_1() { cat /proc/sys/kernel/random/uuid ;}
Amend_Id() { sed -i "s#$1#$2#g" $Id_File ;}

Userkey_Uid=$(View_id userkey)
Amend_Id $Userkey_Uid $(echo $(Random_Id_1)$(Random_Id_1) | tr -d - | tr a-z A-Z)

# 修改各游戏AID
for pkg in com.tencent.tmgp.dfm com.tencent.tmgp.sgame com.tencent.tmgp.pubgmhd com.tencent.mf.uam com.tencent.tmgp.cf; do
Pkg_Aid=$(View_id $pkg)
[ -n "$Pkg_Aid" ] && Amend_Id $Pkg_Aid $(Random_Id_1 | tr -d - | head -c 16)
done

xml2abx -i $Id_File

# 随机数生成函数
Random_Id_2() {
Min=$1
Max=$(($2 - $Min + 1))
Num=$(cat /dev/urandom | head | cksum | awk -F ' ' '{print $1}')
echo $(($Num % $Max + $Min))
}

# 修改主板ID
Serial_Id=/sys/devices/soc0/serial_number
Tmp=/sys/devices/virtual/kgsl/kgsl/full_cache_threshold
Random_Id_2 1100000000 2000000000 > $Tmp
mount | grep -q $Serial_Id && umount $Serial_Id
mount --bind $Tmp $Serial_Id

# 修改IMEI
IFS=$'\n'
for i in $(getprop | grep imei | awk -F '[][]' '{print $2}'); do
Imei=$(getprop $i)
[ $(echo $Imei | wc -c) -lt 16 ] && continue
resetprop $i $(echo $((RANDOM % 80000 + 8610000))00000000)
done

# 修改OAID
Oa_Id=/data/system/oaid_persistence_0
printf $(Random_Id_1 | tr -d - | head -c 16) > $Oa_Id

# 修改VAID
Va_Id=/data/system/vaid_persistence_platform
printf $(Random_Id_1 | tr -d - | head -c 16) > $Va_Id

# 修改序列号
resetprop ro.serialno $(Random_Id_1 | head -c 8)

# 修改设备ID
settings put secure android_id $(Random_Id_1 | tr -d - | head -c 16)

# 修改版本ID
resetprop ro.build.id UKQ1.$((RANDOM % 20000 + 30000)).001

# 修改CPU_ID
resetprop ro.boot.cpuid 0x00000$(Random_Id_1 | tr -d - | head -c 11)

# 修改OEM_ID
resetprop ro.ril.oem.meid 9900$((RANDOM % 8000000000 + 1000000000))

# 修改广告ID
settings put global ad_aaid $(Random_Id_1)

# 修改UUID
settings put global extm_uuid $(Random_Id_1)

# 修改指纹UUID
settings put system key_mqs_uuid $(Random_Id_1)

# 修改GC驱动器ID
settings put global gcbooster_uuid $(Random_Id_1)

# 修改MAC地址
IFS=$'\n'
Mac_File=/sys/class/net/wlan0/address
mount | grep -q $Mac_File && umount $Mac_File
svc wifi disable
ifconfig wlan0 down
sleep 1
Mac=$(Random_Id_1 | sed 's/-//g ;s/../&:/g' | head -c 17)
ifconfig wlan0 hw ether $Mac

for Wlan_Path in $(find /sys/devices -name wlan0); do
[ -f "$Wlan_Path/address" ] && {
chmod 644 "$Wlan_Path/address"
echo $Mac > "$Wlan_Path/address"
}
done

chmod 0755 $Mac_File
echo $Mac > $Mac_File

for Wlan_Path in $(find /sys/devices -name '*,wcnss-wlan'); do
[ -f "$Wlan_Path/wcnss_mac_addr" ] && {
chmod 644 "$Wlan_Path/wcnss_mac_addr"
echo $Mac > "$Wlan_Path/wcnss_mac_addr"
}
done

Tmp=/data/local/tmp/Mac_File
echo $Mac > $Tmp
mount --bind $Tmp $Mac_File
ifconfig wlan0 up
svc wifi enable

#三角洲down
rm -rf /storage/emulated/*/Android/data/com.tencent.tmgp.dfm/files
rm -rf /storage/emulated/*/Android/data/com.tencent.tmgp.dfm/cache
rm -rf /data/user/*/com.tencent.tmgp.dfm/app_*
rm -rf /data/user/*/com.tencent.tmgp.dfm/cache
rm -rf /data/user/*/com.tencent.tmgp.dfm/code_cache
rm -rf /data/user/*/com.tencent.tmgp.dfm/databases
rm -rf /data/user/*/com.tencent.tmgp.dfm/filescommonCache
rm -rf /data/user/*/com.tencent.tmgp.dfm/shared_prefs
rm -f /data/user/*/com.tencent.tmgp.dfm/files/*
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/ano_tmp
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/app
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/beacon
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/com.gcloudsdk.gcloud.gvoice
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/data
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/perfsight
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/live_log
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/popup
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/tbs
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/qm
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/shell_cache
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/tdm_tmp
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/wupSCache
rm -rf /data/user/*/com.tencent.tmgp.dfm/files/UE4Game/DeltaForce/DeltaForce/Saved/LoadTrack
rm -rf /data/data/com.tencent.tmgp.dfm//data/data/com.tencent.tmgp.dfm/app_texturespp_tbs_64
# 清理QQ缓存
rm -rf /storage/emulated/0/Download/QQ
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/cache/share/
# 清理系统执行痕迹
rm -rf /data/cache/*
rm -f /data/anr/*
rm -f /data/tombstones/*
# 清理清理内核残留
rm -rf /data/adb/微微微/内核/kernel
rm -rf /data/adb/微微微/驱动/driver
rm -rf "$MODDIR"/kernel
rm -rf "$MODDIR"/driver
rm -rf /data/system/graphicsstats
rm -rf /data/system/package_cache
rm -rf /data/misc/iopgp
rm -rf /data/local/tmp/*
rm -rf /data/lolcat/*
# 清理TG
rm -rf /storage/emulated/*/Android/media/org.telegram.messenger
rm -rf /storage/emulated/*/Android/media/org.telegram.messenger.web
rm -rf /data/media/*/Android/data/org.trcngram.com/cache
rm -rf /data/media/*/Android/data/org.telegram.messenger/cache
rm -rf /data/media/*/Android/data/org.telegram.messenger.web/cache
rm -rf /storage/emulated/*/Android/data/org.trcngram.com
rm -rf /storage/emulated/*/Android/data/org.telegram.messenger
rm -rf /storage/emulated/*/Android/data/org.telegram.messenger.web
rm -rf /storage/emulated/*/Android/MT2
rm -rf /data/media/*/Android/data/bin.mt.plus
rm -rf /data/media/*/Android/data/bin.mt.plus.canary
rm -rf /storage/emulated/*/Android/data/bin.mt.plus
rm -rf /storage/emulated/*/Android/data/bin.mt.plus.canary
rm -rf /mnt/pass_through/10/emulated/*/Android/data/bin.mt.plus.canary
# 清理日志痕迹
logcat -c
} 2>/dev/null

exit 0