// 脚本路径（KSU模块目录绝对路径，避免相对路径错误）
const MODULE_ID = "bszip"; // 和module.prop中的id一致
const SCRIPT_PATHS = {
    btn1: `/data/adb/modules/${MODULE_ID}/scripts/script1.sh`,
    btn2: `/data/adb/modules/${MODULE_ID}/scripts/script2.sh`,
    btn3: `/data/adb/modules/${MODULE_ID}/scripts/script3.sh`,
    btn4: `/data/adb/modules/${MODULE_ID}/scripts/script4.sh`
};

// 页面加载完成后绑定按钮事件
document.addEventListener('DOMContentLoaded', () => {
    // 初始化结果框
    document.getElementById('resultBox').innerHTML = "悲伤压缩包";
    
    // 为4个按钮绑定点击事件
    document.getElementById('btn1').addEventListener('click', () => executeScript('btn1'));
    document.getElementById('btn2').addEventListener('click', () => executeScript('btn2'));
    document.getElementById('btn3').addEventListener('click', () => executeScript('btn3'));
    document.getElementById('btn4').addEventListener('click', () => executeScript('btn4'));
});

/**
 * 【核心新增】封装KSU直接执行命令的函数（替代/api/exec接口）
 * @param {string} command - 要执行的shell命令
 * @returns {Promise<{stdout: string, stderr: string, code: number}>} 执行结果
 */
function execKsuCommand(command) {
    return new Promise((resolve, reject) => {
        // 生成唯一回调名，避免冲突
        const callbackName = `exec_callback_${Date.now()}`;
        
        // 定义KSU执行后的回调函数
        window[callbackName] = (errno, stdout, stderr) => {
            // 执行完成后删除全局回调函数，避免内存泄漏
            delete window[callbackName];
            // 返回标准化结果（和原接口格式对齐，减少修改）
            resolve({
                code: errno,       // 退出码：0成功，非0失败
                stdout: stdout || "", // 标准输出
                stderr: stderr || ""  // 错误输出
            });
        };

        // 检查KSU API是否存在（直接交互的核心）
        if (typeof ksu !== 'undefined' && ksu.exec) {
            // 调用KSU原生API执行命令（直接交互，无中间接口）
            ksu.exec(command, "{}", callbackName);
        } else {
            // API不存在时返回错误
            reject({
                code: -1,
                stdout: "",
                stderr: "❌ KSU JS API未找到！请确认KSU版本支持WebUI API，且页面运行在KSU环境中"
            });
        }
    });
}

/**
 * 执行指定的sh脚本（修改核心：去掉fetch，改用直接调用ksu.exec）
 * @param {string} btnId - 按钮ID（对应脚本）
 */
async function executeScript(btnId) {
    const scriptPath = SCRIPT_PATHS[btnId];
    const resultBox = document.getElementById('resultBox');
    const btnName = document.getElementById(btnId).textContent;
    const timestamp = new Date().toLocaleString();

    // 1. 显示执行中提示+调试信息（保留原有逻辑）
    resultBox.innerHTML += `\n=== [${timestamp}] 开始执行：${btnName} ===\n`;
    resultBox.innerHTML += `调试：脚本路径 → ${scriptPath}\n`;
    resultBox.scrollTop = resultBox.scrollHeight; // 滚动到最底部

    // 2. 构造执行命令（保留原有权限检查逻辑）
    const execCmd = `
        echo "=== 前置检查 ===";
        if [ -f "${scriptPath}" ]; then
            echo "✅ 加载脚本成功：${scriptPath}";
            chmod 777 "${scriptPath}" && echo "✅ 执行脚本中";
            echo "=== 脚本执行输出 ===";
            sh "${scriptPath}";
            echo "=== 脚本执行结束，退出码：$? ===";
        else
            echo "❌ 脚本文件不存在：${scriptPath}";
            echo "❌ 当前模块目录文件列表：";
            ls -l /data/adb/modules/${MODULE_ID}/scripts/;
            exit 1;
        fi
    `.replace(/\n/g, ' ').trim(); // 去掉换行符，适配shell执行

    try {
        // 3. 调用KSU直接执行命令（核心修改：替换fetch为execKsuCommand）
        const data = await execKsuCommand(execCmd);

        // 4. 显示完整执行结果（保留原有格式，和原逻辑对齐）
        resultBox.innerHTML += `执行退出码：${data.code}\n`;
        resultBox.innerHTML += `标准输出：\n${data.stdout || "无"}\n`;
        if (data.stderr) {
            resultBox.innerHTML += `错误输出：\n${data.stderr}\n`;
        }
        if (data.code === 0) {
            resultBox.innerHTML += `=== 执行完成：${btnName}（成功）===\n`;
        } else {
            resultBox.innerHTML += `=== 执行完成：${btnName}（失败）===\n`;
        }
    } catch (err) {
        // 5. 捕获所有异常（KSU API不存在/执行异常等）
        resultBox.innerHTML += `❌ 执行异常：${err.stderr || err.message}\n`;
        resultBox.innerHTML += `=== 执行完成：${btnName}（异常）===\n`;
    } finally {
        // 始终滚动到最底部
        resultBox.scrollTop = resultBox.scrollHeight;
    }
}

/**
 * 清空结果显示框（保留原有逻辑）
 */
function clearResult() {
    document.getElementById('resultBox').innerHTML = "执行完毕";
}