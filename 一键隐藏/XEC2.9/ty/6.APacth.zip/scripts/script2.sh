#!/system/bin/sh
# 脚本功能：收集基础包名+用户第三方应用包名，去重后写入目标文件，输出新增包名
# 优化点：修复shebang、调整逻辑顺序、增加错误处理、优化对比逻辑、增强提示

# ===================== 1. 定义常量（规范命名+注释） =====================
# 模块基础目录
MODULE_DIR="/data/adb/bszip"
# Tricky Store目标目录
TARGET_DIR="/data/adb/tricky_store"
# 临时文件（新包名）
TEMP_NEW="${MODULE_DIR}/target_new.txt"
# 最终目标文件
FINAL_TARGET="${TARGET_DIR}/target.txt"
# 临时文件（旧包名，用于对比）
TEMP_OLD="${MODULE_DIR}/target_old.txt"
# 基础包名列表（单独定义，便于维护）
BASE_PACKAGES=(
    "android"
    "com.google.android.gms"
    "com.google.android.gsf"
    "com.android.vending"
)

# ===================== 2. 通用函数（错误处理+日志） =====================
# 错误提示并退出
error_exit() {
    echo "[ERROR] $1"
    # 清理临时文件
    [ -f "$TEMP_NEW" ] && rm -f "$TEMP_NEW"
    [ -f "$TEMP_OLD" ] && rm -f "$TEMP_OLD"
    exit 1
}

# 信息提示
info_echo() {
    echo "[INFO] $1"
}

# ===================== 3. 前置检查与目录创建 =====================
# 检查是否有Root权限（Android脚本必备）
if [ "$(id -u)" -ne 0 ]; then
    error_exit "请以Root权限执行此脚本！"
fi

# 创建模块目录（带错误处理）
info_echo "创建必要目录..."
mkdir -p "$MODULE_DIR" || error_exit "创建目录 $MODULE_DIR 失败！"
mkdir -p "$TARGET_DIR" || error_exit "创建目录 $TARGET_DIR 失败！"

# 设置目录权限（避免后续写入失败）
chmod 755 "$MODULE_DIR" "$TARGET_DIR"

# ===================== 4. 备份旧的目标文件（用于对比新增） =====================
info_echo "备份旧的包名列表..."
if [ -f "$FINAL_TARGET" ]; then
    cp -f "$FINAL_TARGET" "$TEMP_OLD" || error_exit "备份旧文件失败！"
else
    # 首次执行时创建空的旧文件，避免对比报错
    touch "$TEMP_OLD" || error_exit "创建空的旧文件失败！"
fi

# ===================== 5. 生成新的包名列表（基础+用户第三方） =====================
info_echo "写入基础包名..."
# 写入基础包名（覆盖临时文件，避免残留）
printf "%s\n" "${BASE_PACKAGES[@]}" > "$TEMP_NEW" || error_exit "写入基础包名失败！"

info_echo "收集用户安装的第三方应用包名..."
# 收集用户第三方应用包名（-3 表示第三方应用，过滤空行）
USER_PACKAGES=$(pm list packages -3 2>/dev/null | sed 's/package://g' | grep -v '^$')
# 避免追加空内容（用户无第三方应用时跳过）
if [ -n "$USER_PACKAGES" ]; then
    echo "$USER_PACKAGES" >> "$TEMP_NEW" || error_exit "追加用户包名失败！"
    info_echo "共收集到 $(echo "$USER_PACKAGES" | wc -l) 个第三方应用包名"
else
    info_echo "未检测到用户安装的第三方应用包名"
fi

# ===================== 6. 去重处理（核心优化：先去重再覆盖目标文件） =====================
info_echo "去重处理包名列表..."
# 去重+排序（-u 去重，-o 输出到目标文件）
sort -u "$TEMP_NEW" -o "$TEMP_NEW" || error_exit "包名去重失败！"

# 将去重后的文件覆盖到最终目标文件
cp -f "$TEMP_NEW" "$FINAL_TARGET" || error_exit "写入最终目标文件失败！"
# 设置文件权限（确保其他程序可读取）
chmod 644 "$FINAL_TARGET"

# ===================== 7. 对比新旧包名，输出新增内容 =====================
info_echo "对比新旧包名列表..."
# comm -13 ：仅显示新文件有、旧文件没有的行（即新增包名）
ADDED=$(comm -13 "$TEMP_OLD" "$TEMP_NEW" 2>/dev/null)

if [ -n "$ADDED" ]; then
    echo -e "\n【新增的包名】："
    echo "$ADDED"
    # 统计新增数量
    ADDED_COUNT=$(echo "$ADDED" | wc -l)
    info_echo "本次共新增 $ADDED_COUNT 个包名"
else
    echo -e "\n✅ 无新增包名，执行成功！"
fi

# ===================== 8. 清理临时文件（健壮性优化） =====================
info_echo "清理临时文件..."
# rm -f 避免文件不存在时报错
rm -f "$TEMP_NEW" "$TEMP_OLD"

# ===================== 9. 最终提示 =====================
TOTAL_COUNT=$(wc -l < "$FINAL_TARGET")
echo -e "\n===== 脚本执行完成 ====="
echo "📌 最终包名列表文件：$FINAL_TARGET"
echo "📌 总包名数量：$TOTAL_COUNT 个"
exit 0