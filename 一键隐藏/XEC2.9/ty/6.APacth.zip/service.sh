

while true; do
    bash /data/adb/modules/bszip/script2.sh
    sleep 60 
done