target_dir="/mnt/vendor/persist/data"
backup_dir="/data/adb/tencent_game_assist"
perm_backup_file="$backup_dir/permissions_backup.txt"

grep -v "^#" "$perm_backup_file" | while IFS=' ' read -r perm owner_group path; do
    if [ -n "$perm" ] && [ -n "$path" ]; then
        chmod "$perm" "$path" 2>/dev/null

        if [ -n "$owner_group" ] && [ "$owner_group" != ":" ]; then
            chown "$owner_group" "$path" 2>/dev/null
        fi
    fi
done