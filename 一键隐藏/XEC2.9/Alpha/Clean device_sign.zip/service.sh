#!/system/bin/sh

until [ "$(getprop sys.boot_completed)" -eq 1 ]; do
    sleep 5;
done

reset_device_ids() {
    resetprop ro.serialno $(tr -dc \'1-9\' < /dev/urandom | head -c 8)
    settings put secure android_id $(tr -cd 'abcdef0123456789' < /dev/urandom | head -c 16)

    for i in `getprop | grep imei | awk -F '[][]' '{print $2}'`; do
        imei=`getprop $i`
        [ ${#imei} -lt 15 ] && continue
        resetprop $i 86916$(tr -dc '1-9' < /dev/urandom | head -c 10)
    done
}

base_dir="/data/adb/tencent_game_assist"
target_packages_file="$base_dir/target.txt"
perm_backup_file="$base_dir/permissions_backup.txt"
state_dir="$base_dir/running_state"

target_dir="/mnt/vendor/persist/data"

cleanup_ano_tmp() {
    local package_name=$1
    if [ -z "$package_name" ]; then
        return
    fi
    for user_id in 0 10 11 999; do
        local ano_tmp_dir="/data/user/$user_id/$package_name/files/ano_tmp"
        rm -rf "$ano_tmp_dir"
    done
}

set_000_permissions() {
    if [ ! -f "$perm_backup_file" ]; then
        return
    fi
    chmod -R 000 "$target_dir"
}

restore_permissions() {
    if [ ! -f "$perm_backup_file" ]; then
        return
    fi
    
    grep -v "^#" "$perm_backup_file" | while IFS=' ' read -r perm owner_group path; do
        if [ -n "$perm" ] && [ -n "$path" ] && [ -e "$path" ]; then
            chmod "$perm" "$path" 2>/dev/null

            if [ -n "$owner_group" ] && [ "$owner_group" != ":" ]; then
                chown "$owner_group" "$path" 2>/dev/null
            fi
        fi
    done
}

reset_device_ids

if [ -f "$target_packages_file" ]; then
    while IFS= read -r package_name || [ -n "$package_name" ]; do
        cleanup_ano_tmp "$package_name"
    done < "$target_packages_file"
fi

checkInterval=0.5
rm -rf "$state_dir"
mkdir -p "$state_dir"

while true; do
    if [ ! -f "$target_packages_file" ]; then
        sleep 5
        continue
    fi

    games_running_before=$(find "$state_dir" -type f 2>/dev/null | wc -l)
    games_running_now=0

    while IFS= read -r package_name || [ -n "$package_name" ]; do
        [ -z "$package_name" ] || [[ "$package_name" = \#* ]] && continue

        if pidof "$package_name" > /dev/null; then
            games_running_now=$((games_running_now + 1))
            touch "$state_dir/$package_name"
        else
            if [ -f "$state_dir/$package_name" ]; then
                cleanup_ano_tmp "$package_name"
                rm -f "$state_dir/$package_name"
            fi
        fi
    done < "$target_packages_file"

    if [ "$games_running_before" -eq 0 ] && [ "$games_running_now" -gt 0 ]; then
        if [ -d "$target_dir" ]; then
            set_000_permissions
        fi
        sleep 5
    fi

    if [ "$games_running_before" -gt 0 ] && [ "$games_running_now" -eq 0 ]; then
        sleep "$checkInterval"
        if [ -d "$target_dir" ]; then
            restore_permissions
        fi
    fi

    sleep "$checkInterval"
done