target_dir="/mnt/vendor/persist/data"
backup_dir="/data/adb/tencent_game_assist"
perm_backup_file="$backup_dir/permissions_backup.txt"
target_file="$backup_dir/target.txt"

if [ ! -d "$backup_dir" ]; then
    ui_print "- 正在创建模块工作目录: $backup_dir"
    mkdir -p "$backup_dir"
    if [ $? -ne 0 ]; then
        ui_print "  - 错误：无法创建目录 $backup_dir"
        abort "  - 安装失败！"
    fi
else
    ui_print "- 模块工作目录已存在: $backup_dir"
fi

backup_permissions() {
    ui_print "- 正在检查目标目录..."
    if [ ! -d "$target_dir" ]; then
        ui_print "  - 目标目录 $target_dir 不存在，已跳过权限备份。"
    else
        ui_print "- 正在备份原始权限信息..."
        
        echo "# Permissions backup - $(date)" > "$perm_backup_file"
        echo "# Format: permissions owner:group path" >> "$perm_backup_file"
        
        find "$target_dir" -exec stat -c "%a %U:%G %n" {} \; >> "$perm_backup_file"
        
        ui_print "  - 权限信息已成功备份到: $perm_backup_file"
        ui_print "  - 重要：此文件是恢复权限所必需的，请勿删除！"
    fi
    
    ui_print " "
}

create_target_list() {
    ui_print "- 正在检查游戏列表文件..."

    if [ ! -f "$target_file" ]; then
        ui_print "  - 列表文件不存在，正在创建并写入默认包名..."
        
        cat <<EOF > "$target_file"
com.tencent.tmgp.sgame
com.tencent.tmgp.codev
com.tencent.tmgp.cf
com.tencent.tmgp.dfm
com.tencent.tmgp.pubgmhd
com.tencent.mf.uam
EOF
        ui_print "  - 成功创建: $target_file"
    else
        ui_print "  - 列表文件已存在，将保留用户自定义内容。"
    fi
    ui_print "  - 提示：您可以随时编辑此文件来增删游戏包名。"
}

backup_permissions

create_target_list

ui_print " "
ui_print "- 模块环境设置完成！"
ui_print "- 脚本作者: 七七"
am start -a android.intent.action.VIEW -d"mqq://im/chat?chat_type=wpa&uin=3300501509&version=1&src_type=web"