# 清理日志设置
qlog() {
    resetprop -n persist.logd.size ""
    resetprop -n persist.logd.size.crash ""
    resetprop -n persist.logd.size.main ""
    resetprop -n persist.log.tag ""

    echo "- API问题和USB各种问题"
    # 调试模式
    resetprop ro.crypto.state encrypted
    resetprop ro.debuggable 0
    resetprop -n init.svc.adbd stopped
    settings delete global hidden_api_policy
    settings delete global hidden_api_policy_p_apps
    settings delete global hidden_api_policy_pre_p_apps
    settings delete global hidden_api_blacklist_exemptions
    settings delete global hidden_api_blacklist_exe
    
}


# 包名管理
run_ls_command() {
    SCRIPT="/data/adb/tricky_store/一键获取包名.sh"
    TARGET="/data/adb/tricky_store/target.txt"
    su -c "$SCRIPT"

    while true; do
        if [ -f "$TARGET" ]; then
            if [[ -s "$TARGET" && ! $(LC_ALL=C grep -q '[^[:alnum:]_.]' "$TARGET") ]]; then
                echo "- 包名文件合法，进入休眠..."
                sleep 21600
            else
                echo "- 包名文件不合法，重新获取..."
                > "$TARGET"
                su -c "$SCRIPT"
                sleep 10
            fi
        else
            echo "- 包名文件不存在，重新获取..."
            su -c "$SCRIPT"
            sleep 10
        fi
    done
}
sho() {

# 检查是否存在 /data/adb/modules/zygisk_shamiko 文件夹
if [ -d "/data/adb/modules/zygisk_shamiko" ]; then
  echo "zygisk_shamiko 文件夹存在，脚本不运行。"
else
  echo "zygisk_shamiko 文件夹不存在，正在运行脚本..."
  
  # 以下为实际脚本内容
  check_reset_prop() {
    local NAME=$1
    local EXPECTED=$2
    local VALUE=$(resetprop $NAME)
    [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop $NAME $EXPECTED
  }

  contains_reset_prop() {
    local NAME=$1
    local CONTAINS=$2
    local NEWVAL=$3
    [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop $NAME $NEWVAL
  }

  resetprop -w sys.boot_completed 0

  check_reset_prop "ro.boot.vbmeta.device_state" "locked"
  check_reset_prop "ro.boot.verifiedbootstate" "green"
  check_reset_prop "ro.boot.flash.locked" "1"
  check_reset_prop "ro.boot.veritymode" "enforcing"
  check_reset_prop "ro.boot.warranty_bit" "0"
  check_reset_prop "ro.warranty_bit" "0"
  check_reset_prop "ro.debuggable" "0"
  check_reset_prop "ro.force.debuggable" "0"
  check_reset_prop "ro.secure" "1"
  check_reset_prop "ro.adb.secure" "1"
  check_reset_prop "ro.build.type" "user"
  check_reset_prop "ro.build.tags" "release-keys"
  check_reset_prop "ro.vendor.boot.warranty_bit" "0"
  check_reset_prop "ro.vendor.warranty_bit" "0"
  check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
  check_reset_prop "vendor.boot.verifiedbootstate" "green"
  check_reset_prop "sys.oem_unlock_allowed" "0"

  # MIUI specific
  check_reset_prop "ro.secureboot.lockstate" "locked"

  # Realme specific
  check_reset_prop "ro.boot.realmebootstate" "green"
  check_reset_prop "ro.boot.realme.lockstate" "1"

  # Hide that we booted from recovery when magisk is in recovery mode
  contains_reset_prop "ro.bootmode" "recovery" "unknown"
  contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
  contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"
fi
}
# 定义检测路径

#关闭自动白名单，删除以下代码
whitelist(){
FILE_PATH="/data/adb/shamiko/whitelist"

while true; do
    # 检测文件是否存在
    if [ ! -f "$FILE_PATH" ]; then
        echo "检测到 $FILE_PATH 不存在，正在创建..."
        touch "$FILE_PATH"
        echo "文件已创建: $FILE_PATH"
    else
        echo "$FILE_PATH 已存在，无需创建。"
    fi
    # 等待1分钟后再次检测
    sleep 60
done
}
#到这里



initt(){
if [ $(getprop init.svc.adbd) != "stopped" ]; then
    echo "检测到修改痕迹"
    resetprop -n init.svc.adbd stopped
    echo "已隐藏修改痕迹"
fi
if [ $(getprop init.svc.flash_recovery) != "stopped" ]; then
    echo "检测到修改痕迹"
    resetprop init.svc.flash_recovery stopped
    echo "已隐藏修改痕迹"
fi
}
# 后台运行各模块
qlog &
run_ls_command &
sho &
whitelist &

initt &