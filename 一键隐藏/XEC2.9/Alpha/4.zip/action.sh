# 检测VPN连接状态
vpn_detected=$(ip route | grep -q 'tun' && echo true || echo false)

# 如果检测到VPN连接
if [ "$vpn_detected" = "true" ]; then

echo " "
    echo "- VPN已连接"
    
PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
MODDIR=/data/adb/modules/playintegrityfix
version=$(grep "^version=" $MODDIR/module.prop | sed 's/version=//g' )
echo " "
echo "- 版本：PlayIntegrityFix $version"

download() { busybox wget -T 10 --no-check-certificate -qO "$2" "$1"; }
if command -v curl > /dev/null 2>&1; then
	download() { curl --connect-timeout 10 -s -o "$2" "$1"; }
fi

sleep_pause() {
	# APatch 和 KernelSU 需要这个
	if [ -z "$MMRL" ] && { [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; }; then
		sleep 5
	fi
}

set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
    echo " "
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p")
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}

download_fail() {
echo " "
	echo "- 下载失败!"
	echo " "
	echo "- 退出运行!"
	echo " "
	echo "- 尝试关闭VPN-使用本地模式提取"

	sleep_pause
	exit 1
}

# 让我们尝试使用 tmpfs 进行处理
TEMPDIR="$MODDIR/temp" #fallback
[ -w /sbin ] && TEMPDIR="/sbin/playintegrityfix"
[ -w /debug_ramdisk ] && TEMPDIR="/debug_ramdisk/playintegrityfix"
mkdir -p "$TEMPDIR"
cd "$TEMPDIR"
echo " "
# 保存下载的网页到 /data/adb/tricky_store/
download https://developer.android.com/topic/generic-system-image/releases /data/adb/tricky_store/PIXEL_GSI_HTML || download_fail
echo "- 选择指纹版本：$(grep -m1 -o 'li>.*(Beta)' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d\> -f2)"
echo " "
echo "- 更新指纹日期：$(grep -m1 -o 'Date:.*' /data/adb/tricky_store/PIXEL_GSI_HTML)"

current_timestamp=$(date +%s)
threshold_timestamp=1740312000 # Baklava still not name as 16. TODO: Need to know what is the actually time of changeing the name of release.
if [ "$current_timestamp" -lt "$threshold_timestamp" ]; then
    RELEASE="Baklava"
else
    RELEASE="$(grep -m1 'corresponding Google Pixel builds' PIXEL_GSI_HTML | grep -o '/versions/.*' | cut -d/ -f3)"
fi
ID="$(grep -m1 -o 'Build:.*' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d' ' -f2)"
INCREMENTAL="$(grep -m1 -o "$ID-.*-" /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d- -f2)"

download "https://developer.android.com$(grep -m1 'corresponding Google Pixel builds' /data/adb/tricky_store/PIXEL_GSI_HTML | grep -o 'href.*' | cut -d\" -f2)" /data/adb/tricky_store/PIXEL_GET_HTML || download_fail

download "https://developer.android.com$(grep -m1 'Pixel downloads page' /data/adb/tricky_store/PIXEL_GET_HTML | grep -o 'href.*' | cut -d\" -f2)" /data/adb/tricky_store/PIXEL_BETA_HTML || download_fail

MODEL_LIST="$(grep -A1 'tr id=' /data/adb/tricky_store/PIXEL_BETA_HTML | grep 'td' | sed 's;.*<td>.*</td>;\1;')"
PRODUCT_LIST="$(grep -o 'factory/.*_beta' /data/adb/tricky_store/PIXEL_BETA_HTML | cut -d/ -f2)"

download https://source.android.com/docs/security/bulletin/pixel /data/adb/tricky_store/PIXEL_SECBULL_HTML || download_fail
echo " "
SECURITY_PATCH="$(grep -A15 "$(grep -m1 -o 'Security patch level:.*' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d' ' -f4-)" /data/adb/tricky_store/PIXEL_SECBULL_HTML | grep -m1 -B1 '</tr>' | grep 'td' | sed 's;.*<td>.*</td>;\1;')"
echo " "

set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p" | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')  # 去除 HTML 标签和空格
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}

# 选择指纹设备输出
echo "- 选择指纹设备："
[ -z "$PRODUCT" ] && set_random_beta
echo " "

echo "- $MODEL ($PRODUCT)"

echo " "
sdk_version="$(getprop ro.build.version.sdk)"
sdk_version="${sdk_version:-25}"
echo "- 设备SDK版本： $sdk_version"
echo " "
cat <<EOF | tee pif.json
{
  "FINGERPRINT": "google/$PRODUCT/$DEVICE:$RELEASE/$ID/$INCREMENTAL:user/release-keys",
  "MANUFACTURER": "Google",
  "MODEL": "$(echo "$MODEL" | sed 's/<[^>]*>//g' | sed 's/^[ \t]*//g' | sed 's/[ \t]*$//g')",
  "SECURITY_PATCH": "$(echo "$SECURITY_PATCH" | sed 's/<[^>]*>//g' | sed 's/^[ \t]*//g' | sed 's/[ \t]*$//g')",
  "DEVICE_INITIAL_SDK_INT": $sdk_version
}
EOF
echo " "
cat "$TEMPDIR/pif.json" > /data/adb/modules/playintegrityfix/pif.json
echo "- 新的指纹保存到：/data/adb/modules/playintegrityfix/pif.json"
echo " "
echo "- 清理缓冲"
rm -rf "$TEMPDIR"
echo " "
for i in $(busybox pidof com.google.android.gms.unstable); do
	echo "- 停止谷歌进程pid $i"
	kill -9 "$i"
done
echo " "
echo "- 更新指纹完成!"
echo " "
echo "- 本地模式在/data/adb/tricky_store/，下次可以不用连接VPN更新指纹"
echo "- 本地模式在/data/adb/tricky_store/，下次可以不用连接VPN更新指纹"
echo "- 本地模式在/data/adb/tricky_store/，下次可以不用连接VPN更新指纹"
echo " "
sleep_pause
else
    # VPN未连接的提示
echo " "
echo "- VPN未连接"
echo " "
echo "- 执行本地模式-提取"
PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
MODDIR=/data/adb/modules/playintegrityfix
version=$(grep "^version=" $MODDIR/module.prop | sed 's/version=//g' )
echo " "
echo "- 版本：PlayIntegrityFix $version"


# 检查网页文件是否存在
LOCAL_TMP_DIR="/data/adb/tricky_store"
if [ ! -f "$LOCAL_TMP_DIR/PIXEL_GSI_HTML" ] || \
   [ ! -f "$LOCAL_TMP_DIR/PIXEL_GET_HTML" ] || \
   [ ! -f "$LOCAL_TMP_DIR/PIXEL_BETA_HTML" ] || \
   [ ! -f "$LOCAL_TMP_DIR/PIXEL_SECBULL_HTML" ]; then
    echo "错误：网页文件不存在。请确保以下文件已存在于 $LOCAL_TMP_DIR："
    echo "- PIXEL_GSI_HTML"
    echo "- PIXEL_GET_HTML"
    echo "- PIXEL_BETA_HTML"
    echo "- PIXEL_SECBULL_HTML"
    echo "退出脚本。"
    exit 1
fi

# 本地提取文件
TEMPDIR="$MODDIR/temp" #fallback
[ -w /sbin ] && TEMPDIR="/sbin/playintegrityfix"
[ -w /debug_ramdisk ] && TEMPDIR="/debug_ramdisk/playintegrityfix"
mkdir -p "$TEMPDIR"
cd "$TEMPDIR"

# 提取文件到临时目录
cp "$LOCAL_TMP_DIR/PIXEL_GSI_HTML" "$TEMPDIR/PIXEL_GSI_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_GET_HTML" "$TEMPDIR/PIXEL_GET_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_BETA_HTML" "$TEMPDIR/PIXEL_BETA_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_SECBULL_HTML" "$TEMPDIR/PIXEL_SECBULL_HTML"

# 本地提取文件
TEMPDIR="$MODDIR/temp" #fallback
[ -w /sbin ] && TEMPDIR="/sbin/playintegrityfix"
[ -w /debug_ramdisk ] && TEMPDIR="/debug_ramdisk/playintegrityfix"
mkdir -p "$TEMPDIR"
cd "$TEMPDIR"

# 假设文件位于 /data/adb/tricky_store/
LOCAL_TMP_DIR="/data/adb/tricky_store"
echo " "
# 提取文件到临时目录
cp "$LOCAL_TMP_DIR/PIXEL_GSI_HTML" "$TEMPDIR/PIXEL_GSI_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_GET_HTML" "$TEMPDIR/PIXEL_GET_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_BETA_HTML" "$TEMPDIR/PIXEL_BETA_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_SECBULL_HTML" "$TEMPDIR/PIXEL_SECBULL_HTML"

# 定义 sleep_pause 函数
sleep_pause() {
	# APatch 和 KernelSU 需要这个
	if [ -z "$MMRL" ] && { [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; }; then
		sleep 5
	fi
}

# 定义 set_random_beta 函数
set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p" | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')  # 去除 HTML 标签和空格
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}
# 从本地文件中提取信息
echo "- 选择指纹版本：$(grep -m1 -o 'li>.*(Beta)' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d\> -f2)"
echo " "
echo "- 更新指纹日期：$(grep -m1 -o 'Date:.*' /data/adb/tricky_store/PIXEL_GSI_HTML)"
echo " "
RELEASE="$(grep -m1 'corresponding Google Pixel builds' PIXEL_GSI_HTML | grep -o '/versions/.*' | cut -d/ -f3)"
ID="$(grep -m1 -o 'Build:.*' PIXEL_GSI_HTML | cut -d' ' -f2)"
INCREMENTAL="$(grep -m1 -o "$ID-.*-" PIXEL_GSI_HTML | cut -d- -f2)"

MODEL_LIST="$(grep -A1 'tr id=' PIXEL_BETA_HTML | grep 'td' | sed 's;.*<td>.*</td>;\1;' | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"  # 去除 HTML 标签和空格
PRODUCT_LIST="$(grep -o 'factory/.*_beta' PIXEL_BETA_HTML | cut -d/ -f2)"

SECURITY_PATCH="$(grep -A15 "$(grep -m1 -o 'Security patch level:.*' PIXEL_GSI_HTML | cut -d' ' -f4-)" PIXEL_SECBULL_HTML | grep -m1 -B1 '</tr>' | grep 'td' | sed 's;.*<td>.*</td>;\1;' | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"  # 去除 HTML 标签和空格


set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p" | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')  # 去除 HTML 标签和空格
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}

# 选择指纹设备输出
echo "- 选择指纹设备："
[ -z "$PRODUCT" ] && set_random_beta
echo " "

echo "- $MODEL ($PRODUCT)"
echo " "
sdk_version="$(getprop ro.build.version.sdk)"
sdk_version="${sdk_version:-25}"
echo "- 设备SDK版本： $sdk_version"
echo " "


cat <<EOF | tee pif.json
{
  "FINGERPRINT": "google/$PRODUCT/$DEVICE:$RELEASE/$ID/$INCREMENTAL:user/release-keys",
  "MANUFACTURER": "Google",
  "MODEL": "$MODEL",
  "SECURITY_PATCH": "$SECURITY_PATCH",
  "DEVICE_INITIAL_SDK_INT": $sdk_version
}
EOF
echo " "
cat "$TEMPDIR/pif.json" > /data/adb/modules/playintegrityfix/pif.json
echo "- 新的指纹保存到：/data/adb/modules/playintegrityfix/pif.json"
echo " "
echo "- 清理缓冲"
rm -rf "$TEMPDIR"
echo " "
for i in $(busybox pidof com.google.android.gms.unstable); do
	echo "- 停止谷歌进程pid $i"
	kill -9 "$i"
done
echo " "
echo "- 更新指纹完成!"
sleep_pause
fi