su -c "
if [ ! -f /data/adb/tricky_store/target.txt ]; then
  touch /data/adb/tricky_store/target.txt
fi

for pkg in \$(pm list packages | sed 's/package://g'); do
  if ! grep -q \"\$pkg\" /data/adb/tricky_store/target.txt; then
    echo \"\$pkg\" >> /data/adb/tricky_store/target.txt
  fi
done"