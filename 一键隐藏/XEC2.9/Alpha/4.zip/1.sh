# 模块目录路径
MODULES_DIR="/data/adb/modules"

# 排除的模块列表（确保与实际文件夹名称完全一致）
EXCLUDE_MODULES=("zygisksu" "tricky_store" "playintegrityfix" "zn_magisk_compat" "zygisk_shamiko" "zygisk_lsposed")

# 检查路径是否存在
if [ ! -d "$MODULES_DIR" ]; then
    echo "- 目录不存在：$MODULES_DIR"
    exit 1
fi

# 遍历每个子目录
for dir in "$MODULES_DIR"/*; do
    # 检查是否为目录
    if [ -d "$dir" ]; then
        # 提取文件夹名称
        folder_name=$(basename "$dir")
        # 检查是否在排除列表中
        if printf '%s\n' "${EXCLUDE_MODULES[@]}" | grep -q -x "$folder_name"; then
            echo "- 跳过模块：$folder_name"
        else
            touch "$dir/disable"
            echo "- 自动暂停模块：$dir"
        fi
    fi
done

echo "- 暂停模块完成"