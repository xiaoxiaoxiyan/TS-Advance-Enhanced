# 不要在恢复模式下刷机！
if ! $BOOTMODE; then
    ui_print "*********************************************************"
    ui_print "! 从恢复模式安装不受支持"
    ui_print "! 恢复模式不好"
    ui_print "! 请通过Magisk / KernelSU / APatch应用安装"
    abort    "*********************************************************"
fi

# Android 8以下版本错误
if [ "$API" -lt 26 ]; then
    abort "! 您不能在Android < 8.0上使用此模块"
fi

check_zygisk() {
    local ZYGISK_MODULE="/data/adb/modules/zygisksu"
    local MAGISK_DIR="/data/adb/magisk"
    local ZYGISK_MSG="Zygisk未启用。请执行以下操作之一：
    - 在Magisk设置中启用Zygisk
    - 安装ZygiskNext或ReZygisk模块"

    # 检查Zygisk模块目录是否存在
    if [ -d "$ZYGISK_MODULE" ]; then
        return 0
    fi

    # 如果Magisk已安装，检查Zygisk设置
    if [ -d "$MAGISK_DIR" ]; then
        # 从Magisk数据库查询Zygisk状态
        local ZYGISK_STATUS
        ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';")

        # 检查Zygisk是否被禁用
        if [ "$ZYGISK_STATUS" = "value=0" ]; then
            abort "$ZYGISK_MSG"
        fi
    else
        abort "$ZYGISK_MSG"
    fi
}

# 模块需要Zygisk才能工作
check_zygisk

# safetynet-fix模块已过时，与PIF不兼容
SNFix="/data/adb/modules/safetynet-fix"
if [ -d "$SNFix" ]; then
    ui_print "! safetynet-fix模块已过时，并且与PIF不兼容，将在下次重启时删除"
    ui_print "! 请勿安装它"
    touch "$SNFix"/remove
fi

# playcurl警告
if [ -d "/data/adb/modules/playcurl" ]; then
    ui_print "! playcurl可能会覆盖指纹并导致无效，请小心！"
fi

# MagiskHidePropsConf模块在Android 8+中已过时，但不应引起问题
if [ -d "/data/adb/modules/MagiskHidePropsConf" ]; then
    ui_print "! 警告，MagiskHidePropsConf模块可能会导致PIF出现问题。"
fi

# 检查自定义指纹
if [ -f "/data/adb/pif.json" ]; then
    ui_print "!!! 警告 !!!"
    ui_print "- 您正在使用自定义pif.json (/data/adb/pif.json)"
    ui_print "- 如果您无法通过认证测试，请删除该文件！"
fi

# give exec perm to action.sh
chmod +x "$MODPATH/action.sh"

# action.sh, ap 10927, ksu 11981
if { [ "$KSU" = "true" ] && [ "$KSU_VER_CODE" -ge 11981 ]; } || 
	{ [ "$APATCH" = "true" ] && [ "$APATCH_VER_CODE" -ge 10927 ]; }; then
	# we dont need the webui workaround
	# since manager has action
	rm -rf "$MODPATH/webroot"
fi
TARGET_DIR="/data/adb/tricky_store"
if [ ! -d "$TARGET_DIR" ]; then
  ui_print ""
  ui_print "- 正在为您创建新的tricky_store文件夹..."
  mkdir -p "$TARGET_DIR"
fi

for file in keybox.xml "一键获取包名.sh" PIXEL_BETA_HTML PIXEL_GET_HTML PIXEL_GSI_HTML PIXEL_SECBULL_HTML auto.sh 1.sh; do
  # 提取文件
  extract "$ZIPFILE" "$file" "$MODPATH"
  
  # 检查文件是否提取成功
  if [ -e "$MODPATH/$file" ]; then
    # 移动并覆盖目标文件
    mv -f "$MODPATH/$file" "$TARGET_DIR/$file" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
      ui_print ""
      ui_print "- 移动/覆盖 $file 文件成功"
    else
      ui_print ""
      ui_print "- 移动/覆盖 $file 文件失败!"
    fi
  else
    ui_print ""
    ui_print "- 未找到 $file 文件，跳过操作"
  fi
done
# 检测VPN连接状态
vpn_detected=$(ip route | grep -q 'tun' && echo true || echo false)

# 如果检测到VPN连接
if [ "$vpn_detected" = "true" ]; then

echo " "
    echo "- VPN已连接"
    
PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
MODDIR=/data/adb/modules/playintegrityfix
version=$(grep "^version=" $MODDIR/module.prop | sed 's/version=//g' )
echo " "
echo "- 版本：PlayIntegrityFix $version"

download() { busybox wget -T 10 --no-check-certificate -qO "$2" "$1"; }
if command -v curl > /dev/null 2>&1; then
	download() { curl --connect-timeout 10 -s -o "$2" "$1"; }
fi

sleep_pause() {
	# APatch 和 KernelSU 需要这个
	if [ -z "$MMRL" ] && { [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; }; then
		sleep 5
	fi
}

set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
    echo " "
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p")
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}

download_fail() {
echo " "
	echo "- 下载失败!"
	echo " "
	echo "- 退出运行!"
	echo " "
	echo "- 尝试关闭VPN-使用本地模式提取"

	sleep_pause
	exit 1
}

# 让我们尝试使用 tmpfs 进行处理
TEMPDIR="$MODDIR/temp" #fallback
[ -w /sbin ] && TEMPDIR="/sbin/playintegrityfix"
[ -w /debug_ramdisk ] && TEMPDIR="/debug_ramdisk/playintegrityfix"
mkdir -p "$TEMPDIR"
cd "$TEMPDIR"
echo " "
# 保存下载的网页到 /data/adb/tricky_store/
download https://developer.android.com/topic/generic-system-image/releases /data/adb/tricky_store/PIXEL_GSI_HTML || download_fail
echo "- 选择指纹版本：$(grep -m1 -o 'li>.*(Beta)' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d\> -f2)"
echo " "
echo "- 更新指纹日期：$(grep -m1 -o 'Date:.*' /data/adb/tricky_store/PIXEL_GSI_HTML)"

current_timestamp=$(date +%s)
threshold_timestamp=1740312000 # Baklava still not name as 16. TODO: Need to know what is the actually time of changeing the name of release.
if [ "$current_timestamp" -lt "$threshold_timestamp" ]; then
    RELEASE="Baklava"
else
    RELEASE="$(grep -m1 'corresponding Google Pixel builds' PIXEL_GSI_HTML | grep -o '/versions/.*' | cut -d/ -f3)"
fi
ID="$(grep -m1 -o 'Build:.*' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d' ' -f2)"
INCREMENTAL="$(grep -m1 -o "$ID-.*-" /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d- -f2)"

download "https://developer.android.com$(grep -m1 'corresponding Google Pixel builds' /data/adb/tricky_store/PIXEL_GSI_HTML | grep -o 'href.*' | cut -d\" -f2)" /data/adb/tricky_store/PIXEL_GET_HTML || download_fail

download "https://developer.android.com$(grep -m1 'Pixel downloads page' /data/adb/tricky_store/PIXEL_GET_HTML | grep -o 'href.*' | cut -d\" -f2)" /data/adb/tricky_store/PIXEL_BETA_HTML || download_fail

MODEL_LIST="$(grep -A1 'tr id=' /data/adb/tricky_store/PIXEL_BETA_HTML | grep 'td' | sed 's;.*<td>.*</td>;\1;')"
PRODUCT_LIST="$(grep -o 'factory/.*_beta' /data/adb/tricky_store/PIXEL_BETA_HTML | cut -d/ -f2)"

download https://source.android.com/docs/security/bulletin/pixel /data/adb/tricky_store/PIXEL_SECBULL_HTML || download_fail
echo " "
SECURITY_PATCH="$(grep -A15 "$(grep -m1 -o 'Security patch level:.*' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d' ' -f4-)" /data/adb/tricky_store/PIXEL_SECBULL_HTML | grep -m1 -B1 '</tr>' | grep 'td' | sed 's;.*<td>.*</td>;\1;')"
echo " "

set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p" | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')  # 去除 HTML 标签和空格
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}

# 选择指纹设备输出
echo "- 选择指纹设备："
[ -z "$PRODUCT" ] && set_random_beta
echo " "

echo "- $MODEL ($PRODUCT)"

echo " "
sdk_version="$(getprop ro.build.version.sdk)"
sdk_version="${sdk_version:-25}"
echo "- 设备SDK版本： $sdk_version"
echo " "
cat <<EOF | tee pif.json
{
  "FINGERPRINT": "google/$PRODUCT/$DEVICE:$RELEASE/$ID/$INCREMENTAL:user/release-keys",
  "MANUFACTURER": "Google",
  "MODEL": "$(echo "$MODEL" | sed 's/<[^>]*>//g' | sed 's/^[ \t]*//g' | sed 's/[ \t]*$//g')",
  "SECURITY_PATCH": "$(echo "$SECURITY_PATCH" | sed 's/<[^>]*>//g' | sed 's/^[ \t]*//g' | sed 's/[ \t]*$//g')",
  "DEVICE_INITIAL_SDK_INT": $sdk_version
}
EOF
echo " "
cat "$TEMPDIR/pif.json" > /data/adb/modules/playintegrityfix/pif.json
echo "- 新的指纹保存到：/data/adb/modules/playintegrityfix/pif.json"
echo " "
echo "- 清理缓冲"
rm -rf "$TEMPDIR"
echo " "
for i in $(busybox pidof com.google.android.gms.unstable); do
	echo "- 停止谷歌进程pid $i"
	kill -9 "$i"
done
echo " "
echo "- 更新指纹完成!"
echo " "
echo "- 本地模式在/data/adb/tricky_store/，下次可以不用连接VPN更新指纹"
echo "- 本地模式在/data/adb/tricky_store/，下次可以不用连接VPN更新指纹"
echo "- 本地模式在/data/adb/tricky_store/，下次可以不用连接VPN更新指纹"
echo " "
sleep_pause
else
    # VPN未连接的提示
echo " "
echo "- VPN未连接"
echo " "
echo "- 执行本地模式-提取"
PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
MODDIR=/data/adb/modules/playintegrityfix
version=$(grep "^version=" $MODDIR/module.prop | sed 's/version=//g' )
echo " "
echo "- 版本：PlayIntegrityFix $version"


# 检查网页文件是否存在
LOCAL_TMP_DIR="/data/adb/tricky_store"
if [ ! -f "$LOCAL_TMP_DIR/PIXEL_GSI_HTML" ] || \
   [ ! -f "$LOCAL_TMP_DIR/PIXEL_GET_HTML" ] || \
   [ ! -f "$LOCAL_TMP_DIR/PIXEL_BETA_HTML" ] || \
   [ ! -f "$LOCAL_TMP_DIR/PIXEL_SECBULL_HTML" ]; then
    echo "错误：网页文件不存在。请确保以下文件已存在于 $LOCAL_TMP_DIR："
    echo "- PIXEL_GSI_HTML"
    echo "- PIXEL_GET_HTML"
    echo "- PIXEL_BETA_HTML"
    echo "- PIXEL_SECBULL_HTML"
    echo "退出脚本。"
    exit 1
fi

# 本地提取文件
TEMPDIR="$MODDIR/temp" #fallback
[ -w /sbin ] && TEMPDIR="/sbin/playintegrityfix"
[ -w /debug_ramdisk ] && TEMPDIR="/debug_ramdisk/playintegrityfix"
mkdir -p "$TEMPDIR"
cd "$TEMPDIR"

# 提取文件到临时目录
cp "$LOCAL_TMP_DIR/PIXEL_GSI_HTML" "$TEMPDIR/PIXEL_GSI_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_GET_HTML" "$TEMPDIR/PIXEL_GET_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_BETA_HTML" "$TEMPDIR/PIXEL_BETA_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_SECBULL_HTML" "$TEMPDIR/PIXEL_SECBULL_HTML"

# 本地提取文件
TEMPDIR="$MODDIR/temp" #fallback
[ -w /sbin ] && TEMPDIR="/sbin/playintegrityfix"
[ -w /debug_ramdisk ] && TEMPDIR="/debug_ramdisk/playintegrityfix"
mkdir -p "$TEMPDIR"
cd "$TEMPDIR"

# 假设文件位于 /data/adb/tricky_store/
LOCAL_TMP_DIR="/data/adb/tricky_store"
echo " "
# 提取文件到临时目录
cp "$LOCAL_TMP_DIR/PIXEL_GSI_HTML" "$TEMPDIR/PIXEL_GSI_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_GET_HTML" "$TEMPDIR/PIXEL_GET_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_BETA_HTML" "$TEMPDIR/PIXEL_BETA_HTML"
cp "$LOCAL_TMP_DIR/PIXEL_SECBULL_HTML" "$TEMPDIR/PIXEL_SECBULL_HTML"

# 定义 sleep_pause 函数
sleep_pause() {
	# APatch 和 KernelSU 需要这个
	if [ -z "$MMRL" ] && { [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; }; then
		sleep 5
	fi
}

# 定义 set_random_beta 函数
set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p" | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')  # 去除 HTML 标签和空格
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}
# 从本地文件中提取信息
echo "- 选择指纹版本：$(grep -m1 -o 'li>.*(Beta)' /data/adb/tricky_store/PIXEL_GSI_HTML | cut -d\> -f2)"
echo " "
echo "- 更新指纹日期：$(grep -m1 -o 'Date:.*' /data/adb/tricky_store/PIXEL_GSI_HTML)"
echo " "
RELEASE="$(grep -m1 'corresponding Google Pixel builds' PIXEL_GSI_HTML | grep -o '/versions/.*' | cut -d/ -f3)"
ID="$(grep -m1 -o 'Build:.*' PIXEL_GSI_HTML | cut -d' ' -f2)"
INCREMENTAL="$(grep -m1 -o "$ID-.*-" PIXEL_GSI_HTML | cut -d- -f2)"

MODEL_LIST="$(grep -A1 'tr id=' PIXEL_BETA_HTML | grep 'td' | sed 's;.*<td>.*</td>;\1;' | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"  # 去除 HTML 标签和空格
PRODUCT_LIST="$(grep -o 'factory/.*_beta' PIXEL_BETA_HTML | cut -d/ -f2)"

SECURITY_PATCH="$(grep -A15 "$(grep -m1 -o 'Security patch level:.*' PIXEL_GSI_HTML | cut -d' ' -f4-)" PIXEL_SECBULL_HTML | grep -m1 -B1 '</tr>' | grep 'td' | sed 's;.*<td>.*</td>;\1;' | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"  # 去除 HTML 标签和空格


set_random_beta() {
    if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
        echo "错误：MODEL_LIST 和 PRODUCT_LIST 的长度不同。"
        sleep_pause
        exit 1
    fi
    count=$(echo "$MODEL_LIST" | wc -l)
    rand_index=$(( $$ % count ))
    MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p" | sed 's/<[^>]*>//g' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')  # 去除 HTML 标签和空格
    PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
    DEVICE=$(echo "$PRODUCT" | sed 's/_beta//')
}

# 选择指纹设备输出
echo "- 选择指纹设备："
[ -z "$PRODUCT" ] && set_random_beta
echo " "

echo "- $MODEL ($PRODUCT)"
echo " "
sdk_version="$(getprop ro.build.version.sdk)"
sdk_version="${sdk_version:-25}"
echo "- 设备SDK版本： $sdk_version"
echo " "


cat <<EOF | tee pif.json
{
  "FINGERPRINT": "google/$PRODUCT/$DEVICE:$RELEASE/$ID/$INCREMENTAL:user/release-keys",
  "MANUFACTURER": "Google",
  "MODEL": "$MODEL",
  "SECURITY_PATCH": "$SECURITY_PATCH",
  "DEVICE_INITIAL_SDK_INT": $sdk_version
}
EOF
echo " "
cat "$TEMPDIR/pif.json" > /data/adb/modules/playintegrityfix/pif.json
echo "- 新的指纹保存到：/data/adb/modules/playintegrityfix/pif.json"
echo " "
echo "- 清理缓冲"
rm -rf "$TEMPDIR"
echo " "
for i in $(busybox pidof com.google.android.gms.unstable); do
	echo "- 停止谷歌进程pid $i"
	kill -9 "$i"
done
echo " "
echo "- 更新指纹完成!"
sleep_pause
fi

TARGET_FILE="/data/adb/tricky_store/target.txt"
SCRIPT_FILE="/data/adb/tricky_store/一键获取包名.sh"
su -c "
if [ ! -f /data/adb/tricky_store/target.txt ]; then
  touch /data/adb/tricky_store/target.txt
fi

for pkg in \$(pm list packages | sed 's/package://g'); do
  if ! grep -q \"\$pkg\" /data/adb/tricky_store/target.txt; then
    echo \"\$pkg\" >> /data/adb/tricky_store/target.txt
  fi
done"
ui_print " "
ui_print "- 当前，已自动获取，全部应用包名!"
ui_print " "
ui_print "- 每6小时，自动获取全部应用包名(增强版)"
ui_print " "
ui_print "- 执行成功，去 $TARGET_FILE 看效果"
chmod 755 "$SCRIPT_FILE"
ui_print " "

# 检测 /data/adb/shamiko 文件夹是否存在
if [ -d "/data/adb/shamiko" ]; then
    echo "- 文件夹存在，正在创建 whitelist 文件..."
    touch /data/adb/shamiko/whitelist
    echo "- whitelist 文件已创建。"
else
    echo "- 文件夹 /data/adb/shamiko 不存在，请先检查。"
fi
ui_print " "
ui_print "- 创建：一键获取包名脚本成功，路径:$SCRIPT_FILE"
ui_print " "
su -c "sh /data/adb/tricky_store/1.sh" 
rm -rf "/data/adb/tricky_store/1.sh"
ui_print "- 删除临时文件完成"
ui_print " "