#!/system/bin/sh
MODDIR=${0%/*}
rm -f /data/local/tmp/.usb_plus.lock
rm -f /data/local/tmp/.usb_plus.pid
chmod 755 $MODDIR/system/bin/usb_plus_daemon
nohup $MODDIR/system/bin/usb_plus_daemon >/dev/null 2>&1 &
until [ "$(getprop sys.boot_completed)" = "1" ]
do
sleep 1
done
setprop service.adb.tcp.port 5555
stop adbd
start adbd
