#!/bin/bash
RULES_DIR="/etc/udev/rules.d"
RULE_FILE="51-android.rules"
if [ -f "${RULES_DIR}/${RULE_FILE}" ];then
    rm -f "${RULES_DIR}/${RULE_FILE}"
    echo "已移除 ${RULES_DIR}/${RULE_FILE}"
else
    echo "规则文件不存在，无需删除"
fi
udevadm control --reload-rules
udevadm trigger
if getent group adb >/dev/null 2>&1;then
    groupdel adb
    echo "adb用户组已删除"
fi
echo "卸载完成"
