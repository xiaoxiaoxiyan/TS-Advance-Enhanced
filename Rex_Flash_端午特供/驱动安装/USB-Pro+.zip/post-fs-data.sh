#!/system/bin/sh

MODDIR=${0%/*}

mount --bind $MODDIR/system/bin/adb /system/bin/adb
mount --bind $MODDIR/system/bin/e2fsdroid /system/bin/e2fsdroid
mount --bind $MODDIR/system/bin/etc1tool /system/bin/etc1tool
mount --bind $MODDIR/system/bin/fastboot /system/bin/fastboot
mount --bind $MODDIR/system/bin/hprof-conv /system/bin/hprof-conv
mount --bind $MODDIR/system/bin/img2simg /system/bin/img2simg
mount --bind $MODDIR/system/bin/lpmake /system/bin/lpmake
mount --bind $MODDIR/system/bin/lpunpack /system/bin/lpunpack
mount --bind $MODDIR/system/bin/magiskboot /system/bin/magiskboot
mount --bind $MODDIR/system/bin/make_f2fs /system/bin/make_f2fs
mount --bind $MODDIR/system/bin/make_f2fs_casefold /system/bin/make_f2fs_casefold
mount --bind $MODDIR/system/bin/mke2fs /system/bin/mke2fs
mount --bind $MODDIR/system/bin/simg2img /system/bin/simg2img
mount --bind $MODDIR/system/bin/sload_f2fs /system/bin/sload_f2fs
mount --bind $MODDIR/system/bin/sqlite3 /system/bin/sqlite3
mount --bind $MODDIR/system/bin/payload-dumper-go /system/bin/payload-dumper-go
mount --bind $MODDIR/system/bin/libksud.os /system/bin/libksud.os

resetprop persist.service.adb.enable 1
resetprop persist.sys.usb.config mtp,adb
resetprop sys.usb.config mtp,adb
resetprop ro.debuggable 1
resetprop persist.usb.speed high
resetprop vendor.usb.boost 1
resetprop persist.adb.wifi.enable 1
resetprop persist.sys.usb.force_adb 1
resetprop dev.usb.skip_auth 1
resetprop sys.usb.ffs.ready 1

echo -1 > /sys/module/usbcore/parameters/autosuspend

if [ -f /sys/class/android_usb/android0/enable ]; then
    echo 1 > /sys/class/android_usb/android0/enable
fi

if [ -f /sys/devices/platform/soc/usb_vbus/power/policy ]; then
    echo auto > /sys/devices/platform/soc/usb_vbus/power/policy
fi